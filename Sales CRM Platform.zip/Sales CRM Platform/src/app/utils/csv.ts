export function exportToCSV<T extends object>(data: T[], filename: string) {
  if (!data.length) return;
  const headers = Object.keys(data[0] as Record<string, unknown>);
  const rows = data.map(row =>
    headers.map(h => {
      const v = (row as Record<string, unknown>)[h];
      const s = v === null || v === undefined ? '' : Array.isArray(v) ? v.length.toString() : String(v);
      return `"${s.replace(/"/g, '""')}"`;
    }).join(',')
  );
  const csv = [headers.join(','), ...rows].join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${filename}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}
