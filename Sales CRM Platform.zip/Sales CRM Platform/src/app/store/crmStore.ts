// Reactive store for CRM data – backed by Google Sheets via Apps Script HTTP API
import { useState, useCallback, useEffect } from 'react';
import { useMutateAction, useLoadAction } from '@uibakery/data';
import gsGetAction from '@/actions/gsGet';
import gsCreateAction from '@/actions/gsCreate';
import gsUpdateAction from '@/actions/gsUpdate';
import gsDeleteAction from '@/actions/gsDelete';
import { Lead, Opportunity, Customer, Appointment, Communication, Campaign, MasterItem, newId } from '@/app/data/mockData';
import { APPS_SCRIPT_URL } from '@/app/config/sheetsConfig';

const GS = APPS_SCRIPT_URL; // shorthand

// Helper: turn raw sheet rows (array of objects with string values) into typed records
function parseRow<T>(raw: Record<string, string>): T {
  return raw as unknown as T;
}

export function useCRMStore() {
  const [lastSynced, setLastSynced] = useState<Date>(new Date());

  /* ───────────────────────── Load actions ───────────────────────── */
  const [rawLeads, leadsLoading, , reloadLeads] = useLoadAction(gsGetAction, [], { url: GS, sheet: 'Leads' });
  const [rawOpps, oppsLoading, , reloadOpps] = useLoadAction(gsGetAction, [], { url: GS, sheet: 'Opportunities' });
  const [rawCustomers, custLoading, , reloadCustomers] = useLoadAction(gsGetAction, [], { url: GS, sheet: 'Customers' });
  const [rawAppts, apptsLoading, , reloadAppts] = useLoadAction(gsGetAction, [], { url: GS, sheet: 'Appointments' });
  const [rawComms, commsLoading, , reloadComms] = useLoadAction(gsGetAction, [], { url: GS, sheet: 'Communications' });
  const [rawCampaigns, campsLoading, , reloadCampaigns] = useLoadAction(gsGetAction, [], { url: GS, sheet: 'Campaigns' });
  const [rawUsers] = useLoadAction(gsGetAction, [], { url: GS, sheet: 'Users' });

  const [rawTerritories, , , reloadTerritories] = useLoadAction(gsGetAction, [], { url: GS, sheet: 'MasterTerritory' });
  const [rawGroups, , , reloadGroups] = useLoadAction(gsGetAction, [], { url: GS, sheet: 'MasterGroup' });
  const [rawStages, , , reloadStages] = useLoadAction(gsGetAction, [], { url: GS, sheet: 'MasterStage' });
  const [rawSources, , , reloadSources] = useLoadAction(gsGetAction, [], { url: GS, sheet: 'MasterLeadSource' });
  const [rawPersons, , , reloadPersons] = useLoadAction(gsGetAction, [], { url: GS, sheet: 'MasterSalesPerson' });

  /* ───────────────────────── Mutate actions ───────────────────────── */
  const [gsCreate] = useMutateAction(gsCreateAction);
  const [gsUpdate] = useMutateAction(gsUpdateAction);
  const [gsDelete] = useMutateAction(gsDeleteAction);

  // Update lastSynced whenever any data reloads
  useEffect(() => {
    if (!leadsLoading && !oppsLoading && !custLoading) setLastSynced(new Date());
  }, [leadsLoading, oppsLoading, custLoading]);

  /* ───────────────────────── Derived typed arrays ───────────────────────── */
  const leads: Lead[] = (rawLeads as Record<string, string>[]).map(parseRow<Lead>);
  const opportunities: Opportunity[] = (rawOpps as Record<string, string>[]).map(r => ({
    ...parseRow<Opportunity>(r),
    dealValue: parseFloat(r.dealValue) || 0,
    probability: parseFloat(r.probability) || 0,
    comments: [],
  }));
  const customers: Customer[] = (rawCustomers as Record<string, string>[]).map(parseRow<Customer>);
  const appointments: Appointment[] = (rawAppts as Record<string, string>[]).map(parseRow<Appointment>);
  const communications: Communication[] = (rawComms as Record<string, string>[]).map(parseRow<Communication>);
  const campaigns: Campaign[] = (rawCampaigns as Record<string, string>[]).map(r => ({
    ...parseRow<Campaign>(r),
    target: parseFloat(r.target) || 0,
    leadsGenerated: parseFloat(r.leadsGenerated) || 0,
    conversions: parseFloat(r.conversions) || 0,
    revenue: parseFloat(r.revenue) || 0,
  }));
  const territories: MasterItem[] = (rawTerritories as Record<string, string>[]).map(parseRow<MasterItem>);
  const customerGroups: MasterItem[] = (rawGroups as Record<string, string>[]).map(parseRow<MasterItem>);
  const salesStages: MasterItem[] = (rawStages as Record<string, string>[]).map(parseRow<MasterItem>);
  const leadSources: MasterItem[] = (rawSources as Record<string, string>[]).map(parseRow<MasterItem>);
  const salesPersons: MasterItem[] = (rawPersons as Record<string, string>[]).map(parseRow<MasterItem>);
  const users = rawUsers as Record<string, string>[];

  /* ───────────────────────── LEADS ───────────────────────── */
  const addLead = useCallback(async (l: Omit<Lead, 'id' | 'createdAt' | 'updatedAt' | 'comments'>) => {
    await gsCreate({ url: GS, sheet: 'Leads', data: { ...l, id: newId('L'), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() } });
    reloadLeads();
  }, [gsCreate, reloadLeads]);

  const updateLead = useCallback(async (rowId: string, l: Partial<Lead>) => {
    await gsUpdate({ url: GS, sheet: 'Leads', rowId, data: { ...l, updatedAt: new Date().toISOString() } });
    reloadLeads();
  }, [gsUpdate, reloadLeads]);

  const deleteLead = useCallback(async (rowId: string) => {
    await gsDelete({ url: GS, sheet: 'Leads', rowId });
    reloadLeads();
  }, [gsDelete, reloadLeads]);

  const addLeadComment = useCallback(async (leadRowId: string, text: string, author: string) => {
    await gsCreate({ url: GS, sheet: 'Comments', data: { id: newId('C'), parentSheet: 'Leads', parentId: leadRowId, author, text, createdAt: new Date().toISOString() } });
  }, [gsCreate]);

  /* ───────────────────────── OPPORTUNITIES ───────────────────────── */
  const addOpportunity = useCallback(async (o: Omit<Opportunity, 'id' | 'createdAt' | 'updatedAt' | 'comments'>) => {
    await gsCreate({ url: GS, sheet: 'Opportunities', data: { ...o, id: newId('O'), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() } });
    reloadOpps();
  }, [gsCreate, reloadOpps]);

  const updateOpportunity = useCallback(async (rowId: string, o: Partial<Opportunity>) => {
    await gsUpdate({ url: GS, sheet: 'Opportunities', rowId, data: { ...o, updatedAt: new Date().toISOString() } });
    reloadOpps();
  }, [gsUpdate, reloadOpps]);

  const deleteOpportunity = useCallback(async (rowId: string) => {
    await gsDelete({ url: GS, sheet: 'Opportunities', rowId });
    reloadOpps();
  }, [gsDelete, reloadOpps]);

  const addOppComment = useCallback(async (oppRowId: string, text: string, author: string) => {
    await gsCreate({ url: GS, sheet: 'Comments', data: { id: newId('C'), parentSheet: 'Opportunities', parentId: oppRowId, author, text, createdAt: new Date().toISOString() } });
  }, [gsCreate]);

  /* ───────────────────────── CUSTOMERS ───────────────────────── */
  const addCustomer = useCallback(async (c: Omit<Customer, 'id' | 'createdAt' | 'updatedAt'>) => {
    await gsCreate({ url: GS, sheet: 'Customers', data: { ...c, id: newId('C'), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() } });
    reloadCustomers();
  }, [gsCreate, reloadCustomers]);

  const updateCustomer = useCallback(async (rowId: string, c: Partial<Customer>) => {
    await gsUpdate({ url: GS, sheet: 'Customers', rowId, data: { ...c, updatedAt: new Date().toISOString() } });
    reloadCustomers();
  }, [gsUpdate, reloadCustomers]);

  const deleteCustomer = useCallback(async (rowId: string) => {
    await gsDelete({ url: GS, sheet: 'Customers', rowId });
    reloadCustomers();
  }, [gsDelete, reloadCustomers]);

  /* ───────────────────────── APPOINTMENTS ───────────────────────── */
  const addAppointment = useCallback(async (a: Omit<Appointment, 'id' | 'createdAt' | 'updatedAt'>) => {
    await gsCreate({ url: GS, sheet: 'Appointments', data: { ...a, id: newId('A'), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() } });
    reloadAppts();
  }, [gsCreate, reloadAppts]);

  const updateAppointment = useCallback(async (rowId: string, a: Partial<Appointment>) => {
    await gsUpdate({ url: GS, sheet: 'Appointments', rowId, data: { ...a, updatedAt: new Date().toISOString() } });
    reloadAppts();
  }, [gsUpdate, reloadAppts]);

  const deleteAppointment = useCallback(async (rowId: string) => {
    await gsDelete({ url: GS, sheet: 'Appointments', rowId });
    reloadAppts();
  }, [gsDelete, reloadAppts]);

  /* ───────────────────────── COMMUNICATIONS ───────────────────────── */
  const addCommunication = useCallback(async (c: Omit<Communication, 'id' | 'createdAt' | 'updatedAt'>) => {
    await gsCreate({ url: GS, sheet: 'Communications', data: { ...c, id: newId('CM'), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() } });
    reloadComms();
  }, [gsCreate, reloadComms]);

  const updateCommunication = useCallback(async (rowId: string, c: Partial<Communication>) => {
    await gsUpdate({ url: GS, sheet: 'Communications', rowId, data: { ...c, updatedAt: new Date().toISOString() } });
    reloadComms();
  }, [gsUpdate, reloadComms]);

  const deleteCommunication = useCallback(async (rowId: string) => {
    await gsDelete({ url: GS, sheet: 'Communications', rowId });
    reloadComms();
  }, [gsDelete, reloadComms]);

  /* ───────────────────────── CAMPAIGNS ───────────────────────── */
  const addCampaign = useCallback(async (c: Omit<Campaign, 'id' | 'createdAt' | 'updatedAt'>) => {
    await gsCreate({ url: GS, sheet: 'Campaigns', data: { ...c, id: newId('CAM'), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() } });
    reloadCampaigns();
  }, [gsCreate, reloadCampaigns]);

  const updateCampaign = useCallback(async (rowId: string, c: Partial<Campaign>) => {
    await gsUpdate({ url: GS, sheet: 'Campaigns', rowId, data: { ...c, updatedAt: new Date().toISOString() } });
    reloadCampaigns();
  }, [gsUpdate, reloadCampaigns]);

  const deleteCampaign = useCallback(async (rowId: string) => {
    await gsDelete({ url: GS, sheet: 'Campaigns', rowId });
    reloadCampaigns();
  }, [gsDelete, reloadCampaigns]);

  /* ───────────────────────── MASTER DATA ───────────────────────── */
  const makeMasterOps = (sheet: string, reload: () => void) => ({
    add: async (name: string) => { await gsCreate({ url: GS, sheet, data: { id: newId('M'), name, createdAt: new Date().toISOString() } }); reload(); },
    update: async (rowId: string, name: string) => { await gsUpdate({ url: GS, sheet, rowId, data: { name } }); reload(); },
    remove: async (rowId: string) => { await gsDelete({ url: GS, sheet, rowId }); reload(); },
  });

  return {
    leads, leadsLoading, addLead, updateLead, deleteLead, addLeadComment,
    opportunities, oppsLoading, addOpportunity, updateOpportunity, deleteOpportunity, addOppComment,
    customers, custLoading, addCustomer, updateCustomer, deleteCustomer,
    appointments, apptsLoading, addAppointment, updateAppointment, deleteAppointment,
    communications, commsLoading, addCommunication, updateCommunication, deleteCommunication,
    campaigns, campsLoading, addCampaign, updateCampaign, deleteCampaign,
    territories, customerGroups, salesStages, leadSources, salesPersons,
    users,
    territoryOps: makeMasterOps('MasterTerritory', reloadTerritories),
    customerGroupOps: makeMasterOps('MasterGroup', reloadGroups),
    salesStageOps: makeMasterOps('MasterStage', reloadStages),
    leadSourceOps: makeMasterOps('MasterLeadSource', reloadSources),
    salesPersonOps: makeMasterOps('MasterSalesPerson', reloadPersons),
    lastSynced,
    reloadAll: () => { reloadLeads(); reloadOpps(); reloadCustomers(); reloadAppts(); reloadComms(); reloadCampaigns(); },
  };
}

export type CRMStore = ReturnType<typeof useCRMStore>;
