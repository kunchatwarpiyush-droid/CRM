// Central mock data store for the CRM app
export type LeadStatus = 'New' | 'Contacted' | 'Qualified' | 'Proposal' | 'Negotiation' | 'Won' | 'Lost';
export type LeadSource = 'Website' | 'Referral' | 'Cold Call' | 'Email Campaign' | 'Trade Show' | 'Social Media' | 'Partner';
export type Territory = 'North' | 'South' | 'East' | 'West' | 'Central' | 'International';
export type CustomerGroup = 'Enterprise' | 'SMB' | 'Startup' | 'Government' | 'Education';
export type CommType = 'Call' | 'Email' | 'Follow-up';

export interface Comment {
  id: string;
  author: string;
  text: string;
  createdAt: string;
}

export interface Lead {
  id: string;
  name: string;
  phone: string;
  email: string;
  leadSource: LeadSource;
  territory: Territory;
  assignedSalesperson: string;
  status: LeadStatus;
  createdAt: string;
  updatedAt: string;
  comments: Comment[];
}

export interface Opportunity {
  id: string;
  linkedLeadId: string;
  linkedLeadName: string;
  dealValue: number;
  stage: LeadStatus;
  probability: number;
  expectedCloseDate: string;
  assignedSalesperson: string;
  createdAt: string;
  updatedAt: string;
  comments: Comment[];
}

export interface Customer {
  id: string;
  name: string;
  contact: string;
  group: CustomerGroup;
  territory: Territory;
  createdAt: string;
  updatedAt: string;
}

export interface Appointment {
  id: string;
  title: string;
  date: string;
  time: string;
  assignedTo: string;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface Communication {
  id: string;
  type: CommType;
  linkedTo: string;
  linkedType: 'Lead' | 'Customer';
  subject: string;
  notes: string;
  date: string;
  createdAt: string;
  updatedAt: string;
}

export interface Campaign {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  target: number;
  leadsGenerated: number;
  conversions: number;
  revenue: number;
  createdAt: string;
  updatedAt: string;
}

export interface MasterItem {
  id: string;
  name: string;
  createdAt: string;
}

const now = () => new Date().toISOString();
const d = (s: string) => s;

export const SALESPERSONS = ['Alice Johnson', 'Bob Martinez', 'Carol Lee', 'David Kim', 'Emma Wilson'];

export const leads: Lead[] = [
  { id: 'L001', name: 'Acme Corp', phone: '+1-555-0101', email: 'contact@acme.com', leadSource: 'Website', territory: 'North', assignedSalesperson: 'Alice Johnson', status: 'New', createdAt: d('2026-03-01T09:00:00Z'), updatedAt: d('2026-03-01T09:00:00Z'), comments: [{ id: 'C1', author: 'Alice Johnson', text: 'Initial inquiry received', createdAt: d('2026-03-01T09:30:00Z') }] },
  { id: 'L002', name: 'GlobalTech', phone: '+1-555-0102', email: 'info@globaltech.com', leadSource: 'Referral', territory: 'South', assignedSalesperson: 'Bob Martinez', status: 'Contacted', createdAt: d('2026-03-03T10:00:00Z'), updatedAt: d('2026-03-04T10:00:00Z'), comments: [] },
  { id: 'L003', name: 'StartupXYZ', phone: '+1-555-0103', email: 'hello@startupxyz.io', leadSource: 'Cold Call', territory: 'East', assignedSalesperson: 'Carol Lee', status: 'Qualified', createdAt: d('2026-03-05T11:00:00Z'), updatedAt: d('2026-03-07T11:00:00Z'), comments: [] },
  { id: 'L004', name: 'MegaRetail', phone: '+1-555-0104', email: 'buyer@megaretail.com', leadSource: 'Trade Show', territory: 'West', assignedSalesperson: 'David Kim', status: 'Proposal', createdAt: d('2026-03-06T08:00:00Z'), updatedAt: d('2026-03-10T08:00:00Z'), comments: [] },
  { id: 'L005', name: 'HealthPlus', phone: '+1-555-0105', email: 'admin@healthplus.com', leadSource: 'Email Campaign', territory: 'Central', assignedSalesperson: 'Emma Wilson', status: 'Negotiation', createdAt: d('2026-03-07T12:00:00Z'), updatedAt: d('2026-03-12T12:00:00Z'), comments: [] },
  { id: 'L006', name: 'EduSoft', phone: '+1-555-0106', email: 'sales@edusoft.com', leadSource: 'Social Media', territory: 'North', assignedSalesperson: 'Alice Johnson', status: 'Won', createdAt: d('2026-03-08T09:00:00Z'), updatedAt: d('2026-03-20T09:00:00Z'), comments: [] },
  { id: 'L007', name: 'FinanceHub', phone: '+1-555-0107', email: 'cfo@financehub.com', leadSource: 'Partner', territory: 'South', assignedSalesperson: 'Bob Martinez', status: 'Lost', createdAt: d('2026-03-09T14:00:00Z'), updatedAt: d('2026-03-15T14:00:00Z'), comments: [] },
  { id: 'L008', name: 'LogiCo', phone: '+1-555-0108', email: 'ops@logico.com', leadSource: 'Website', territory: 'East', assignedSalesperson: 'Carol Lee', status: 'New', createdAt: d('2026-03-10T07:00:00Z'), updatedAt: d('2026-03-10T07:00:00Z'), comments: [] },
  { id: 'L009', name: 'CloudBase', phone: '+1-555-0109', email: 'hello@cloudbase.io', leadSource: 'Referral', territory: 'West', assignedSalesperson: 'David Kim', status: 'Contacted', createdAt: d('2026-03-11T10:30:00Z'), updatedAt: d('2026-03-13T10:30:00Z'), comments: [] },
  { id: 'L010', name: 'ManufactPro', phone: '+1-555-0110', email: 'procure@manufactpro.com', leadSource: 'Cold Call', territory: 'Central', assignedSalesperson: 'Emma Wilson', status: 'Qualified', createdAt: d('2026-03-12T13:00:00Z'), updatedAt: d('2026-03-14T13:00:00Z'), comments: [] },
  { id: 'L011', name: 'RetailChain', phone: '+1-555-0111', email: 'buy@retailchain.com', leadSource: 'Trade Show', territory: 'International', assignedSalesperson: 'Alice Johnson', status: 'Proposal', createdAt: d('2026-03-13T09:00:00Z'), updatedAt: d('2026-03-18T09:00:00Z'), comments: [] },
  { id: 'L012', name: 'SecureIT', phone: '+1-555-0112', email: 'ciso@secureit.com', leadSource: 'Email Campaign', territory: 'North', assignedSalesperson: 'Bob Martinez', status: 'New', createdAt: d('2026-03-14T11:00:00Z'), updatedAt: d('2026-03-14T11:00:00Z'), comments: [] },
  { id: 'L013', name: 'TelecomPlus', phone: '+1-555-0113', email: 'network@telecomplus.com', leadSource: 'Social Media', territory: 'South', assignedSalesperson: 'Carol Lee', status: 'Contacted', createdAt: d('2026-03-15T14:00:00Z'), updatedAt: d('2026-03-17T14:00:00Z'), comments: [] },
  { id: 'L014', name: 'AutoDrive', phone: '+1-555-0114', email: 'fleet@autodrive.com', leadSource: 'Partner', territory: 'East', assignedSalesperson: 'David Kim', status: 'Negotiation', createdAt: d('2026-03-16T08:00:00Z'), updatedAt: d('2026-03-22T08:00:00Z'), comments: [] },
  { id: 'L015', name: 'GreenEnergy', phone: '+1-555-0115', email: 'ceo@greenenergy.com', leadSource: 'Website', territory: 'West', assignedSalesperson: 'Emma Wilson', status: 'Qualified', createdAt: d('2026-03-17T10:00:00Z'), updatedAt: d('2026-03-19T10:00:00Z'), comments: [] },
];

export const opportunities: Opportunity[] = [
  { id: 'O001', linkedLeadId: 'L003', linkedLeadName: 'StartupXYZ', dealValue: 45000, stage: 'Qualified', probability: 60, expectedCloseDate: '2026-05-15', assignedSalesperson: 'Carol Lee', createdAt: d('2026-03-07T11:00:00Z'), updatedAt: d('2026-03-07T11:00:00Z'), comments: [] },
  { id: 'O002', linkedLeadId: 'L004', linkedLeadName: 'MegaRetail', dealValue: 120000, stage: 'Proposal', probability: 70, expectedCloseDate: '2026-05-30', assignedSalesperson: 'David Kim', createdAt: d('2026-03-10T08:00:00Z'), updatedAt: d('2026-03-10T08:00:00Z'), comments: [] },
  { id: 'O003', linkedLeadId: 'L005', linkedLeadName: 'HealthPlus', dealValue: 85000, stage: 'Negotiation', probability: 80, expectedCloseDate: '2026-04-20', assignedSalesperson: 'Emma Wilson', createdAt: d('2026-03-12T12:00:00Z'), updatedAt: d('2026-03-12T12:00:00Z'), comments: [] },
  { id: 'O004', linkedLeadId: 'L006', linkedLeadName: 'EduSoft', dealValue: 30000, stage: 'Won', probability: 100, expectedCloseDate: '2026-03-25', assignedSalesperson: 'Alice Johnson', createdAt: d('2026-03-20T09:00:00Z'), updatedAt: d('2026-03-20T09:00:00Z'), comments: [] },
  { id: 'O005', linkedLeadId: 'L011', linkedLeadName: 'RetailChain', dealValue: 200000, stage: 'Proposal', probability: 65, expectedCloseDate: '2026-06-10', assignedSalesperson: 'Alice Johnson', createdAt: d('2026-03-18T09:00:00Z'), updatedAt: d('2026-03-18T09:00:00Z'), comments: [] },
  { id: 'O006', linkedLeadId: 'L014', linkedLeadName: 'AutoDrive', dealValue: 75000, stage: 'Negotiation', probability: 75, expectedCloseDate: '2026-04-30', assignedSalesperson: 'David Kim', createdAt: d('2026-03-22T08:00:00Z'), updatedAt: d('2026-03-22T08:00:00Z'), comments: [] },
  { id: 'O007', linkedLeadId: 'L015', linkedLeadName: 'GreenEnergy', dealValue: 55000, stage: 'Qualified', probability: 55, expectedCloseDate: '2026-05-20', assignedSalesperson: 'Emma Wilson', createdAt: d('2026-03-19T10:00:00Z'), updatedAt: d('2026-03-19T10:00:00Z'), comments: [] },
  { id: 'O008', linkedLeadId: 'L010', linkedLeadName: 'ManufactPro', dealValue: 95000, stage: 'Qualified', probability: 50, expectedCloseDate: '2026-06-01', assignedSalesperson: 'Emma Wilson', createdAt: d('2026-03-14T13:00:00Z'), updatedAt: d('2026-03-14T13:00:00Z'), comments: [] },
  { id: 'O009', linkedLeadId: 'L002', linkedLeadName: 'GlobalTech', dealValue: 60000, stage: 'Proposal', probability: 68, expectedCloseDate: '2026-05-25', assignedSalesperson: 'Bob Martinez', createdAt: d('2026-03-04T10:00:00Z'), updatedAt: d('2026-03-04T10:00:00Z'), comments: [] },
  { id: 'O010', linkedLeadId: 'L001', linkedLeadName: 'Acme Corp', dealValue: 150000, stage: 'New', probability: 20, expectedCloseDate: '2026-07-01', assignedSalesperson: 'Alice Johnson', createdAt: d('2026-03-01T09:00:00Z'), updatedAt: d('2026-03-01T09:00:00Z'), comments: [] },
];

export const customers: Customer[] = [
  { id: 'C001', name: 'Apex Systems', contact: 'john@apex.com', group: 'Enterprise', territory: 'North', createdAt: d('2025-01-10T09:00:00Z'), updatedAt: d('2025-01-10T09:00:00Z') },
  { id: 'C002', name: 'Bright Solutions', contact: 'mary@bright.com', group: 'SMB', territory: 'South', createdAt: d('2025-02-15T10:00:00Z'), updatedAt: d('2025-02-15T10:00:00Z') },
  { id: 'C003', name: 'CoreLogic', contact: 'ops@corelogic.com', group: 'Enterprise', territory: 'East', createdAt: d('2025-03-01T11:00:00Z'), updatedAt: d('2025-03-01T11:00:00Z') },
  { id: 'C004', name: 'DeltaForce', contact: 'cto@delta.com', group: 'Government', territory: 'West', createdAt: d('2025-03-20T12:00:00Z'), updatedAt: d('2025-03-20T12:00:00Z') },
  { id: 'C005', name: 'Echo Dynamics', contact: 'info@echo.com', group: 'Startup', territory: 'Central', createdAt: d('2025-04-05T09:00:00Z'), updatedAt: d('2025-04-05T09:00:00Z') },
  { id: 'C006', name: 'FlexiGroup', contact: 'sales@flexi.com', group: 'SMB', territory: 'International', createdAt: d('2025-04-20T10:00:00Z'), updatedAt: d('2025-04-20T10:00:00Z') },
  { id: 'C007', name: 'GlobalVision', contact: 'ceo@gv.com', group: 'Enterprise', territory: 'North', createdAt: d('2025-05-01T11:00:00Z'), updatedAt: d('2025-05-01T11:00:00Z') },
  { id: 'C008', name: 'HorizonTech', contact: 'tech@horizon.com', group: 'Education', territory: 'South', createdAt: d('2025-05-15T12:00:00Z'), updatedAt: d('2025-05-15T12:00:00Z') },
  { id: 'C009', name: 'InnoVate', contact: 'rd@innovate.io', group: 'Startup', territory: 'East', createdAt: d('2025-06-01T09:00:00Z'), updatedAt: d('2025-06-01T09:00:00Z') },
  { id: 'C010', name: 'JetStream', contact: 'fleet@jet.com', group: 'Government', territory: 'West', createdAt: d('2025-06-15T10:00:00Z'), updatedAt: d('2025-06-15T10:00:00Z') },
  { id: 'C011', name: 'KinetiX', contact: 'biz@kinetix.com', group: 'Enterprise', territory: 'Central', createdAt: d('2025-07-01T11:00:00Z'), updatedAt: d('2025-07-01T11:00:00Z') },
  { id: 'C012', name: 'LuminaLabs', contact: 'lab@lumina.com', group: 'Education', territory: 'International', createdAt: d('2025-07-20T12:00:00Z'), updatedAt: d('2025-07-20T12:00:00Z') },
  { id: 'C013', name: 'MicroLink', contact: 'support@microlink.com', group: 'SMB', territory: 'North', createdAt: d('2025-08-01T09:00:00Z'), updatedAt: d('2025-08-01T09:00:00Z') },
  { id: 'C014', name: 'NexGen', contact: 'hello@nexgen.io', group: 'Startup', territory: 'South', createdAt: d('2025-08-15T10:00:00Z'), updatedAt: d('2025-08-15T10:00:00Z') },
  { id: 'C015', name: 'OmniCom', contact: 'media@omni.com', group: 'Enterprise', territory: 'East', createdAt: d('2025-09-01T11:00:00Z'), updatedAt: d('2025-09-01T11:00:00Z') },
  { id: 'C016', name: 'PrimePath', contact: 'route@prime.com', group: 'Government', territory: 'West', createdAt: d('2025-09-20T12:00:00Z'), updatedAt: d('2025-09-20T12:00:00Z') },
  { id: 'C017', name: 'QuantumAI', contact: 'ai@quantum.com', group: 'Startup', territory: 'Central', createdAt: d('2025-10-05T09:00:00Z'), updatedAt: d('2025-10-05T09:00:00Z') },
  { id: 'C018', name: 'RedwoodSoft', contact: 'dev@redwood.com', group: 'SMB', territory: 'International', createdAt: d('2025-10-20T10:00:00Z'), updatedAt: d('2025-10-20T10:00:00Z') },
  { id: 'C019', name: 'SkyNet Solutions', contact: 'sky@skynet.com', group: 'Enterprise', territory: 'North', createdAt: d('2025-11-01T11:00:00Z'), updatedAt: d('2025-11-01T11:00:00Z') },
  { id: 'C020', name: 'TerraBase', contact: 'geo@terra.com', group: 'Education', territory: 'South', createdAt: d('2025-11-15T12:00:00Z'), updatedAt: d('2025-11-15T12:00:00Z') },
];

export const appointments: Appointment[] = [
  { id: 'A001', title: 'Demo with Acme Corp', date: '2026-04-28', time: '10:00', assignedTo: 'Alice Johnson', notes: 'Prepare product demo slides', createdAt: d('2026-04-25T09:00:00Z'), updatedAt: d('2026-04-25T09:00:00Z') },
  { id: 'A002', title: 'Negotiation call GlobalTech', date: '2026-04-29', time: '14:00', assignedTo: 'Bob Martinez', notes: 'Discuss pricing tiers', createdAt: d('2026-04-25T10:00:00Z'), updatedAt: d('2026-04-25T10:00:00Z') },
  { id: 'A003', title: 'Proposal review HealthPlus', date: '2026-04-30', time: '11:00', assignedTo: 'Emma Wilson', notes: 'Bring updated SOW', createdAt: d('2026-04-26T09:00:00Z'), updatedAt: d('2026-04-26T09:00:00Z') },
  { id: 'A004', title: 'Follow-up MegaRetail', date: '2026-05-01', time: '09:30', assignedTo: 'David Kim', notes: 'Check on legal review status', createdAt: d('2026-04-26T10:00:00Z'), updatedAt: d('2026-04-26T10:00:00Z') },
  { id: 'A005', title: 'Onboarding EduSoft', date: '2026-05-02', time: '13:00', assignedTo: 'Alice Johnson', notes: 'Kick-off meeting post-close', createdAt: d('2026-04-27T09:00:00Z'), updatedAt: d('2026-04-27T09:00:00Z') },
  { id: 'A006', title: 'Cold intro LogiCo', date: '2026-05-03', time: '16:00', assignedTo: 'Carol Lee', notes: 'First call, listen mode', createdAt: d('2026-04-27T10:00:00Z'), updatedAt: d('2026-04-27T10:00:00Z') },
  { id: 'A007', title: 'Renewal discussion Apex Systems', date: '2026-05-05', time: '10:00', assignedTo: 'Bob Martinez', notes: 'Contract renewal + upsell', createdAt: d('2026-04-27T11:00:00Z'), updatedAt: d('2026-04-27T11:00:00Z') },
  { id: 'A008', title: 'Executive QBR CoreLogic', date: '2026-05-07', time: '15:00', assignedTo: 'Emma Wilson', notes: 'Quarterly business review', createdAt: d('2026-04-27T12:00:00Z'), updatedAt: d('2026-04-27T12:00:00Z') },
];

export const communications: Communication[] = [
  { id: 'CM001', type: 'Call', linkedTo: 'Acme Corp', linkedType: 'Lead', subject: 'Initial discovery call', notes: 'Discussed pain points with procurement team', date: '2026-03-02', createdAt: d('2026-03-02T10:00:00Z'), updatedAt: d('2026-03-02T10:00:00Z') },
  { id: 'CM002', type: 'Email', linkedTo: 'GlobalTech', linkedType: 'Lead', subject: 'Sent product brochure', notes: 'Attached full product catalog PDF', date: '2026-03-04', createdAt: d('2026-03-04T09:00:00Z'), updatedAt: d('2026-03-04T09:00:00Z') },
  { id: 'CM003', type: 'Follow-up', linkedTo: 'HealthPlus', linkedType: 'Lead', subject: 'Follow up on proposal', notes: 'Left voicemail, sent follow-up email', date: '2026-03-13', createdAt: d('2026-03-13T11:00:00Z'), updatedAt: d('2026-03-13T11:00:00Z') },
  { id: 'CM004', type: 'Call', linkedTo: 'Apex Systems', linkedType: 'Customer', subject: 'Support check-in', notes: 'All systems running fine', date: '2026-03-15', createdAt: d('2026-03-15T14:00:00Z'), updatedAt: d('2026-03-15T14:00:00Z') },
  { id: 'CM005', type: 'Email', linkedTo: 'CoreLogic', linkedType: 'Customer', subject: 'Q2 roadmap update', notes: 'Shared upcoming feature roadmap', date: '2026-03-20', createdAt: d('2026-03-20T10:00:00Z'), updatedAt: d('2026-03-20T10:00:00Z') },
  { id: 'CM006', type: 'Follow-up', linkedTo: 'AutoDrive', linkedType: 'Lead', subject: 'Negotiation next steps', notes: 'Agreed to reconvene after internal review', date: '2026-03-23', createdAt: d('2026-03-23T13:00:00Z'), updatedAt: d('2026-03-23T13:00:00Z') },
  { id: 'CM007', type: 'Call', linkedTo: 'RetailChain', linkedType: 'Lead', subject: 'Proposal walkthrough', notes: 'Walked through all line items', date: '2026-03-19', createdAt: d('2026-03-19T15:00:00Z'), updatedAt: d('2026-03-19T15:00:00Z') },
  { id: 'CM008', type: 'Email', linkedTo: 'BrightSolutions', linkedType: 'Customer', subject: 'Invoice reminder', notes: 'Sent 30-day invoice reminder', date: '2026-03-25', createdAt: d('2026-03-25T09:00:00Z'), updatedAt: d('2026-03-25T09:00:00Z') },
  { id: 'CM009', type: 'Call', linkedTo: 'GreenEnergy', linkedType: 'Lead', subject: 'Technical requirements', notes: 'Discussed integration specs', date: '2026-03-21', createdAt: d('2026-03-21T11:00:00Z'), updatedAt: d('2026-03-21T11:00:00Z') },
  { id: 'CM010', type: 'Follow-up', linkedTo: 'ManufactPro', linkedType: 'Lead', subject: 'Post-demo follow up', notes: 'Sent comparison sheet as requested', date: '2026-03-26', createdAt: d('2026-03-26T10:00:00Z'), updatedAt: d('2026-03-26T10:00:00Z') },
];

export const campaigns: Campaign[] = [
  { id: 'CAM001', name: 'Q1 Email Blast', startDate: '2026-01-01', endDate: '2026-03-31', target: 50, leadsGenerated: 38, conversions: 12, revenue: 180000, createdAt: d('2025-12-20T09:00:00Z'), updatedAt: d('2026-04-01T09:00:00Z') },
  { id: 'CAM002', name: 'Trade Show Spring', startDate: '2026-02-15', endDate: '2026-02-18', target: 30, leadsGenerated: 24, conversions: 8, revenue: 95000, createdAt: d('2026-01-10T10:00:00Z'), updatedAt: d('2026-02-20T10:00:00Z') },
  { id: 'CAM003', name: 'Social Media Push Q2', startDate: '2026-04-01', endDate: '2026-06-30', target: 80, leadsGenerated: 15, conversions: 3, revenue: 22000, createdAt: d('2026-03-20T11:00:00Z'), updatedAt: d('2026-04-15T11:00:00Z') },
  { id: 'CAM004', name: 'Partner Referral Program', startDate: '2026-01-15', endDate: '2026-12-31', target: 100, leadsGenerated: 42, conversions: 18, revenue: 320000, createdAt: d('2026-01-05T12:00:00Z'), updatedAt: d('2026-04-10T12:00:00Z') },
  { id: 'CAM005', name: 'Cold Outreach Feb', startDate: '2026-02-01', endDate: '2026-02-28', target: 40, leadsGenerated: 18, conversions: 5, revenue: 48000, createdAt: d('2026-01-25T09:00:00Z'), updatedAt: d('2026-03-05T09:00:00Z') },
];

// Master data
export const masterTerritories: MasterItem[] = [
  { id: 'T1', name: 'North', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'T2', name: 'South', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'T3', name: 'East', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'T4', name: 'West', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'T5', name: 'Central', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'T6', name: 'International', createdAt: d('2025-01-01T00:00:00Z') },
];

export const masterCustomerGroups: MasterItem[] = [
  { id: 'CG1', name: 'Enterprise', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'CG2', name: 'SMB', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'CG3', name: 'Startup', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'CG4', name: 'Government', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'CG5', name: 'Education', createdAt: d('2025-01-01T00:00:00Z') },
];

export const masterSalesStages: MasterItem[] = [
  { id: 'SS1', name: 'New', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'SS2', name: 'Qualified', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'SS3', name: 'Proposal', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'SS4', name: 'Negotiation', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'SS5', name: 'Won', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'SS6', name: 'Lost', createdAt: d('2025-01-01T00:00:00Z') },
];

export const masterLeadSources: MasterItem[] = [
  { id: 'LS1', name: 'Website', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'LS2', name: 'Referral', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'LS3', name: 'Cold Call', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'LS4', name: 'Email Campaign', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'LS5', name: 'Trade Show', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'LS6', name: 'Social Media', createdAt: d('2025-01-01T00:00:00Z') },
  { id: 'LS7', name: 'Partner', createdAt: d('2025-01-01T00:00:00Z') },
];

export const masterSalesPersons: MasterItem[] = SALESPERSONS.map((n, i) => ({ id: `SP${i + 1}`, name: n, createdAt: d('2025-01-01T00:00:00Z') }));

export const VERTICAL_WINNING = [
  { name: 'Audio Visual', monthly: [62, 55, 70, 48, 65, 72, 58, 80, 75, 68, 60, 77], yearly: [65] },
  { name: 'AV2', monthly: [45, 50, 42, 55, 60, 58, 52, 48, 63, 55, 49, 54], yearly: [52] },
  { name: 'Home Automation', monthly: [70, 65, 78, 72, 68, 80, 75, 82, 77, 73, 79, 85], yearly: [75] },
  { name: 'IT Hardware', monthly: [55, 60, 58, 62, 65, 70, 67, 72, 68, 71, 66, 74], yearly: [66] },
  { name: 'Rugged Computing', monthly: [40, 45, 38, 50, 48, 52, 55, 58, 53, 49, 51, 57], yearly: [50] },
  { name: 'Security & Surveillance', monthly: [68, 72, 65, 75, 78, 80, 76, 82, 79, 74, 77, 83], yearly: [76] },
  { name: 'Telecommunication', monthly: [58, 62, 55, 65, 68, 70, 64, 72, 69, 66, 63, 71], yearly: [64] },
];

export function newId(prefix: string) {
  return `${prefix}${Date.now().toString(36).toUpperCase()}`;
}
