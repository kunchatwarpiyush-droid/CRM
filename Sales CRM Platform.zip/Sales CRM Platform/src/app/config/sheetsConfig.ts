// ─────────────────────────────────────────────────────────────────────────────
// STEP 1: Paste your deployed Google Apps Script Web App URL below.
// Get it from: Extensions → Apps Script → Deploy → New deployment → Web App URL
// ─────────────────────────────────────────────────────────────────────────────
export const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec';
