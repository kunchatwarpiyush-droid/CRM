'use client';

import '@/index.css';
import { useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import { CRMProvider } from '@/app/context/CRMContext';
import { useCRM } from '@/app/context/CRMContext';
import { Sidebar } from '@/app/components/Sidebar';
import { TopBar } from '@/app/components/TopBar';
import { LoginPage } from '@/app/pages/LoginPage';
import { Dashboard } from '@/app/pages/Dashboard';
import { LeadsPage } from '@/app/pages/LeadsPage';
import { OpportunitiesPage } from '@/app/pages/OpportunitiesPage';
import { CustomersPage } from '@/app/pages/CustomersPage';
import { PipelinePage } from '@/app/pages/PipelinePage';
import { AppointmentsPage } from '@/app/pages/AppointmentsPage';
import { CommunicationsPage } from '@/app/pages/CommunicationsPage';
import { CampaignsPage } from '@/app/pages/CampaignsPage';
import { ReportsPage } from '@/app/pages/ReportsPage';
import { MasterDataPage } from '@/app/pages/MasterDataPage';
import { useNavigate } from 'react-router-dom';

interface User { name: string; role: 'Admin' | 'Salesperson' }

function LoginWrapper({ onLogin }: { onLogin: (u: User) => void }) {
  return <LoginPage onLogin={onLogin} />;
}

function AppShellInner({ user, onLogout }: { user: User; onLogout: () => void }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { lastSynced } = useCRM();
  const navigate = useNavigate();

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-background">
      <TopBar
        user={user}
        onLogout={onLogout}
        onAddLead={() => navigate('/leads')}
        onAddOpportunity={() => navigate('/opportunities')}
        onAddCustomer={() => navigate('/customers')}
        lastSynced={lastSynced}
        onMenuToggle={() => setSidebarOpen(o => !o)}
      />
      <div className="flex flex-1 overflow-hidden">
        {sidebarOpen && (
          <div className="fixed inset-0 bg-black/40 z-30 md:hidden" onClick={() => setSidebarOpen(false)} />
        )}
        <div className={`fixed md:static inset-y-0 left-0 z-40 md:z-auto transition-transform md:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <Sidebar role={user.role} onClose={() => setSidebarOpen(false)} />
        </div>
        <main className="flex-1 overflow-y-auto">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/leads" element={<LeadsPage />} />
            <Route path="/opportunities" element={<OpportunitiesPage />} />
            <Route path="/customers" element={<CustomersPage />} />
            <Route path="/pipeline" element={<PipelinePage />} />
            <Route path="/appointments" element={<AppointmentsPage />} />
            <Route path="/communications" element={<CommunicationsPage />} />
            <Route path="/campaigns" element={<CampaignsPage />} />
            <Route path="/reports" element={<ReportsPage />} />
            {user.role === 'Admin' && <Route path="/master" element={<MasterDataPage />} />}
          </Routes>
        </main>
      </div>
    </div>
  );
}

function AppContent({ user, onLogout }: { user: User; onLogout: () => void }) {
  return (
    <CRMProvider>
      <AppShellInner user={user} onLogout={onLogout} />
    </CRMProvider>
  );
}

function App() {
  const [user, setUser] = useState<User | null>(null);

  return (
    <BrowserRouter>
      {!user
        ? <LoginWrapper onLogin={setUser} />
        : <AppContent user={user} onLogout={() => setUser(null)} />
      }
      <Toaster />
    </BrowserRouter>
  );
}

export default App;
