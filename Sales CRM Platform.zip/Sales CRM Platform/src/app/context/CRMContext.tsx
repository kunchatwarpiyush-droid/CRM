import { createContext, useContext, ReactNode } from 'react';
import { useCRMStore, CRMStore } from '@/app/store/crmStore';

const CRMContext = createContext<CRMStore | null>(null);

export function CRMProvider({ children }: { children: ReactNode }) {
  const store = useCRMStore();
  return <CRMContext.Provider value={store}>{children}</CRMContext.Provider>;
}

export function useCRM(): CRMStore {
  const ctx = useContext(CRMContext);
  if (!ctx) throw new Error('useCRM must be used within CRMProvider');
  return ctx;
}
