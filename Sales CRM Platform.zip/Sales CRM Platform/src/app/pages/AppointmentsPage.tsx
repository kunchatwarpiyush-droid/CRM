import { useState } from 'react';
import { useCRM } from '@/app/context/CRMContext';
import { Appointment } from '@/app/data/mockData';
import { DataTable } from '@/app/components/DataTable';
import { ConfirmDialog } from '@/app/components/ConfirmDialog';
import { SelectFilter } from '@/app/components/SelectFilter';
import { exportToCSV } from '@/app/utils/csv';
import { formatDate } from '@/app/utils/format';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { Plus, Pencil, Trash2 } from 'lucide-react';

const EMPTY: Omit<Appointment, 'id' | 'createdAt' | 'updatedAt'> = { title: '', date: '', time: '', assignedTo: '', notes: '' };

export function AppointmentsPage() {
  const { appointments, addAppointment, updateAppointment, deleteAppointment, salesPersons } = useCRM();
  const { toast } = useToast();

  const [assigneeFilter, setAssigneeFilter] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editItem, setEditItem] = useState<Appointment | null>(null);
  const [form, setForm] = useState({ ...EMPTY });
  const [deleteTarget, setDeleteTarget] = useState<Appointment | null>(null);

  const spNames = salesPersons.length ? salesPersons.map(s => s.name) : ['Alice Johnson', 'Bob Martinez', 'Carol Lee', 'David Kim', 'Emma Wilson'];
  const filtered = assigneeFilter === 'all' ? appointments : appointments.filter(a => a.assignedTo === assigneeFilter);

  const openAdd = () => { setEditItem(null); setForm({ ...EMPTY }); setModalOpen(true); };
  const openEdit = (a: Appointment) => { setEditItem(a); setForm({ title: a.title, date: a.date, time: a.time, assignedTo: a.assignedTo, notes: a.notes }); setModalOpen(true); };

  const handleSubmit = async () => {
    if (!form.title.trim()) return;
    if (editItem) { await updateAppointment(editItem.id, form); toast({ title: 'Appointment updated' }); }
    else { await addAppointment(form); toast({ title: 'Appointment created' }); }
    setModalOpen(false);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    await deleteAppointment(deleteTarget.id);
    toast({ title: 'Appointment deleted', variant: 'destructive' });
    setDeleteTarget(null);
  };

  const columns = [
    { key: 'title', label: 'Title', render: (r: Appointment) => <span className="font-medium">{r.title}</span> },
    { key: 'date', label: 'Date', render: (r: Appointment) => <span>{formatDate(r.date)}</span> },
    { key: 'time', label: 'Time' },
    { key: 'assignedTo', label: 'Assigned To' },
    { key: 'notes', label: 'Notes', render: (r: Appointment) => <span className="text-muted-foreground text-xs truncate max-w-xs block">{r.notes}</span> },
  ];

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold">Appointments</h1><p className="text-muted-foreground text-sm">{appointments.length} scheduled</p></div>
        <Button size="sm" className="gap-1.5" onClick={openAdd}><Plus className="w-4 h-4" />Add Appointment</Button>
      </div>
      <Card><CardContent className="p-6">
        <DataTable
          data={filtered}
          columns={columns}
          searchKeys={['title', 'assignedTo', 'notes']}
          onExport={() => exportToCSV(filtered, 'appointments')}
          extraFilters={
            <SelectFilter value={assigneeFilter} onValueChange={setAssigneeFilter} placeholder="All Assignees"
              options={spNames.map(s => ({ label: s, value: s }))} />
          }
          actions={(a: Appointment) => {
            return (
              <div className="flex items-center gap-1 justify-end">
                <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => openEdit(a)}><Pencil className="w-3.5 h-3.5" /></Button>
                <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => setDeleteTarget(a)}><Trash2 className="w-3.5 h-3.5" /></Button>
              </div>
            );
          }}
        />
      </CardContent></Card>

      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{editItem ? 'Edit Appointment' : 'Add Appointment'}</DialogTitle></DialogHeader>
          <div className="grid gap-3 py-2">
            <div className="grid gap-1.5"><Label>Title *</Label><Input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="Appointment title" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5"><Label>Date</Label><Input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} /></div>
              <div className="grid gap-1.5"><Label>Time</Label><Input type="time" value={form.time} onChange={e => setForm(f => ({ ...f, time: e.target.value }))} /></div>
            </div>
            <div className="grid gap-1.5">
              <Label>Assigned To</Label>
              <Select value={form.assignedTo || 'none'} onValueChange={v => setForm(f => ({ ...f, assignedTo: v === 'none' ? '' : v }))}>
                <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Unassigned</SelectItem>
                  {spNames.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5"><Label>Notes</Label><Textarea rows={3} value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Meeting notes…" /></div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="button" onClick={handleSubmit}>{editItem ? 'Save' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <ConfirmDialog open={!!deleteTarget} title="Delete Appointment" description={`Delete "${deleteTarget?.title}"?`} onConfirm={handleDelete} onCancel={() => setDeleteTarget(null)} />
    </div>
  );
}
