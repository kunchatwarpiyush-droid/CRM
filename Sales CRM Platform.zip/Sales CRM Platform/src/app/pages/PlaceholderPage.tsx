import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Construction } from 'lucide-react';

export function PlaceholderPage({ title }: { title: string }) {
  return (
    <div className="p-6">
      <Card>
        <CardHeader>
          <CardTitle>{title}</CardTitle>
        </CardHeader>
        <CardContent className="p-6 pt-0 flex flex-col items-center justify-center py-12 gap-3 text-muted-foreground">
          <Construction className="w-10 h-10" />
          <p className="text-sm">This module is coming soon.</p>
        </CardContent>
      </Card>
    </div>
  );
}
