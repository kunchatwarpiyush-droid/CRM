import { useState } from 'react';
import { useCRM } from '@/app/context/CRMContext';
import { Opportunity, LeadStatus } from '@/app/data/mockData';
import { formatCurrency } from '@/app/utils/format';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const STAGES: LeadStatus[] = ['New', 'Qualified', 'Proposal', 'Negotiation', 'Won', 'Lost'];
const STAGE_COLORS: Record<string, string> = {
  New: 'border-t-blue-500', Qualified: 'border-t-green-500', Proposal: 'border-t-purple-500',
  Negotiation: 'border-t-orange-500', Won: 'border-t-emerald-500', Lost: 'border-t-red-500'
};
const HEADER_COLORS: Record<string, string> = {
  New: 'bg-blue-50 text-blue-700', Qualified: 'bg-green-50 text-green-700',
  Proposal: 'bg-purple-50 text-purple-700', Negotiation: 'bg-orange-50 text-orange-700',
  Won: 'bg-emerald-50 text-emerald-700', Lost: 'bg-red-50 text-red-700'
};

function initials(name: string) {
  return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
}

export function PipelinePage() {
  const { opportunities, updateOpportunity } = useCRM();
  const { toast } = useToast();
  const [dragging, setDragging] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState<string | null>(null);

  const byStage = (stage: LeadStatus) => opportunities.filter(o => o.stage === stage);
  const stageTotal = (stage: LeadStatus) => byStage(stage).reduce((s, o) => s + o.dealValue, 0);

  const handleDrop = async (stage: LeadStatus) => {
    if (!dragging || dragging === stage) return;
    const opp = opportunities.find(o => o.id === dragging);
    if (!opp) return;
    await updateOpportunity(opp.id, { stage });
    toast({ description: `Moved "${opp.linkedLeadName}" to ${stage}` });
    setDragging(null);
    setDragOver(null);
  };

  const handleMoveSelect = async (opp: Opportunity, stage: LeadStatus) => {
    await updateOpportunity(opp.id, { stage });
    toast({ description: `Moved "${opp.linkedLeadName}" to ${stage}` });
  };

  return (
    <div className="p-6 space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Sales Pipeline</h1>
        <p className="text-muted-foreground text-sm">Drag cards between stages to update</p>
      </div>
      <div className="flex gap-3 overflow-x-auto pb-2">
        {STAGES.map(stage => (
          <div
            key={stage}
            className={`flex-shrink-0 w-60 rounded-lg border-2 transition-colors ${dragOver === stage ? 'border-primary bg-primary/5' : 'border-transparent'}`}
            onDragOver={e => { e.preventDefault(); setDragOver(stage); }}
            onDragLeave={() => setDragOver(null)}
            onDrop={() => handleDrop(stage)}
          >
            {/* Column Header */}
            <div className={`rounded-t-lg px-3 py-2.5 ${HEADER_COLORS[stage]}`}>
              <div className="flex items-center justify-between">
                <span className="font-semibold text-sm">{stage}</span>
                <Badge variant="secondary" className="text-xs">{byStage(stage).length}</Badge>
              </div>
              <p className="text-xs mt-0.5 opacity-80">{formatCurrency(stageTotal(stage))}</p>
            </div>

            {/* Cards */}
            <div className="p-2 space-y-2 min-h-16">
              {byStage(stage).map(opp => (
                <div
                  key={opp.id}
                  draggable
                  onDragStart={() => setDragging(opp.id)}
                  onDragEnd={() => { setDragging(null); setDragOver(null); }}
                  className={`bg-card border rounded-md p-3 cursor-grab active:cursor-grabbing shadow-sm hover:shadow-md transition-shadow border-t-4 ${STAGE_COLORS[stage]}`}
                >
                  <p className="font-medium text-sm leading-tight">{opp.linkedLeadName}</p>
                  <p className="text-base font-bold mt-1">{formatCurrency(opp.dealValue)}</p>
                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center gap-1.5">
                      <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center font-semibold">
                        {initials(opp.assignedSalesperson || '??')}
                      </div>
                      <span className="text-xs text-muted-foreground">{opp.probability}%</span>
                    </div>
                    <Select value={opp.stage} onValueChange={v => handleMoveSelect(opp, v as LeadStatus)}>
                      <SelectTrigger className="h-6 w-24 text-xs px-1.5 border-dashed">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {STAGES.map(s => <SelectItem key={s} value={s} className="text-xs">{s}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              ))}
              {byStage(stage).length === 0 && (
                <p className="text-xs text-muted-foreground text-center py-4">Drop here</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
