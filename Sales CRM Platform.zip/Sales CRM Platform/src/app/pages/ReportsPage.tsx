import { useState, useMemo } from 'react';
import { useCRM } from '@/app/context/CRMContext';
import { VERTICAL_WINNING, Territory } from '@/app/data/mockData';
import { formatCurrency, formatDate } from '@/app/utils/format';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { BarChart3, TrendingUp, Users, Clock, UserX, Megaphone, Award, ChevronLeft } from 'lucide-react';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const STAGE_COLORS: Record<string, string> = { New: '#3b82f6', Qualified: '#22c55e', Proposal: '#a855f7', Negotiation: '#f97316', Won: '#10b981', Lost: '#ef4444' };
const TERRITORIES: Territory[] = ['North', 'South', 'East', 'West', 'Central', 'International'];

const REPORTS = [
  { id: 'pipeline', title: 'Sales Pipeline Analytics', icon: BarChart3, description: 'Deal values and counts across all pipeline stages' },
  { id: 'summary', title: 'Opportunity Summary by Stage', icon: TrendingUp, description: 'Grouped stage breakdown with averages' },
  { id: 'engaged', title: 'Prospects Engaged but Not Converted', icon: Users, description: 'Leads active >30 days without conversion' },
  { id: 'response', title: 'First Response Time', icon: Clock, description: 'Average time from lead creation to first contact' },
  { id: 'inactive', title: 'Inactive Customers', icon: UserX, description: 'Customers with no activity in 90+ days' },
  { id: 'campaign', title: 'Campaign Efficiency', icon: Megaphone, description: 'Cost-per-lead and conversion rates per campaign' },
  { id: 'owner', title: 'Lead Owner Efficiency', icon: Award, description: 'Win rates and pipeline values per salesperson' },
];

export function ReportsPage() {
  const { leads, opportunities, customers, campaigns } = useCRM();
  const [activeReport, setActiveReport] = useState<string | null>(null);
  const [customVertical, setCustomVertical] = useState(0);
  const [customView, setCustomView] = useState<'monthly' | 'yearly'>('monthly');
  const [territoryFilter, setTerritoryFilter] = useState<Territory[]>([...TERRITORIES]);

  /* --- Pipeline Analytics --- */
  const pipelineData = useMemo(() => {
    return ['New','Qualified','Proposal','Negotiation','Won','Lost'].map(stage => ({
      stage, count: opportunities.filter(o => o.stage === stage).length,
      value: opportunities.filter(o => o.stage === stage).reduce((s, o) => s + o.dealValue, 0),
    }));
  }, [opportunities]);

  /* --- Opportunity Summary --- */
  const oppSummary = useMemo(() => pipelineData.map(row => ({
    ...row,
    avgProb: opportunities.filter(o => o.stage === row.stage).reduce((s, o) => s + o.probability, 0) / (row.count || 1),
  })), [pipelineData, opportunities]);

  /* --- Prospects engaged not converted --- */
  const notConverted = useMemo(() => {
    const cutoff = new Date(); cutoff.setDate(cutoff.getDate() - 30);
    return leads.filter(l => !['Won','Lost'].includes(l.status) && new Date(l.createdAt) < cutoff);
  }, [leads]);

  /* --- First response time (mock calc) --- */
  const responseData = useMemo(() => {
    const sp: Record<string, number[]> = {};
    leads.forEach(l => {
      const days = Math.floor((new Date(l.updatedAt).getTime() - new Date(l.createdAt).getTime()) / 86400000);
      if (!sp[l.assignedSalesperson]) sp[l.assignedSalesperson] = [];
      sp[l.assignedSalesperson].push(days);
    });
    return Object.entries(sp).map(([name, days]) => ({ name: name.split(' ')[0], avgDays: Math.round(days.reduce((a,b) => a+b, 0) / days.length) }));
  }, [leads]);

  /* --- Inactive customers (mock: created >180d ago) --- */
  const inactiveCustomers = useMemo(() => {
    const cutoff = new Date(); cutoff.setDate(cutoff.getDate() - 180);
    return customers.filter(c => new Date(c.createdAt) < cutoff);
  }, [customers]);

  /* --- Campaign efficiency --- */
  const campaignEff = useMemo(() => campaigns.map(c => ({
    name: c.name.substring(0, 20), costPerLead: c.leadsGenerated > 0 ? Math.round(c.revenue / c.leadsGenerated) : 0,
    convRate: c.leadsGenerated > 0 ? Math.round((c.conversions / c.leadsGenerated) * 100) : 0,
    revenue: c.revenue,
  })), [campaigns]);

  /* --- Owner efficiency --- */
  const ownerEff = useMemo(() => {
    const sp: Record<string, { won: number; total: number; value: number }> = {};
    opportunities.forEach(o => {
      if (!sp[o.assignedSalesperson]) sp[o.assignedSalesperson] = { won: 0, total: 0, value: 0 };
      sp[o.assignedSalesperson].total++;
      if (o.stage === 'Won') { sp[o.assignedSalesperson].won++; sp[o.assignedSalesperson].value += o.dealValue; }
    });
    return Object.entries(sp).map(([name, d]) => ({ name: name.split(' ')[0], winRate: Math.round((d.won / d.total) * 100), value: d.value, total: d.total }));
  }, [opportunities]);

  /* --- Territory data --- */
  const territoryData = useMemo(() => TERRITORIES.map(t => ({
    territory: t,
    revenue: opportunities.filter(o => {
      const lead = leads.find(l => l.id === o.linkedLeadId);
      return lead?.territory === t && o.stage === 'Won';
    }).reduce((s, o) => s + o.dealValue, 0),
    convRate: (() => {
      const total = leads.filter(l => l.territory === t).length;
      const won = leads.filter(l => l.territory === t && l.status === 'Won').length;
      return total > 0 ? Math.round((won / total) * 100) : 0;
    })()
  })).filter(t => territoryFilter.includes(t.territory)), [opportunities, leads, territoryFilter]);

  /* --- Custom vertical report --- */
  const vertData = VERTICAL_WINNING[customVertical];
  const chartData = customView === 'monthly'
    ? MONTHS.map((m, i) => ({ name: m, winning: vertData.monthly[i] }))
    : [{ name: vertData.name, winning: vertData.yearly[0] }];

  if (activeReport) {
    const report = REPORTS.find(r => r.id === activeReport)!;
    return (
      <div className="p-6 space-y-4">
        <div className="flex items-center gap-3">
          <Button type="button" size="sm" variant="ghost" onClick={() => setActiveReport(null)}><ChevronLeft className="w-4 h-4" /></Button>
          <h1 className="text-2xl font-bold">{report.title}</h1>
        </div>

        {activeReport === 'pipeline' && (
          <div className="grid gap-4">
            <Card><CardHeader><CardTitle className="text-base">Deal Value by Stage</CardTitle></CardHeader>
              <CardContent className="p-6 pt-0">
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={pipelineData}><CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="stage" tick={{ fontSize: 12 }} /><YAxis tick={{ fontSize: 11 }} tickFormatter={v => `$${(v/1000).toFixed(0)}k`} />
                    <Tooltip formatter={(v) => [formatCurrency(v as number), 'Value']} />
                    <Bar dataKey="value" radius={[4,4,0,0]}>{pipelineData.map((r,i) => <Cell key={i} fill={STAGE_COLORS[r.stage]} />)}</Bar>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent></Card>
            <Card><CardContent className="p-6"><table className="w-full text-sm"><thead><tr className="border-b"><th className="text-left py-2 text-muted-foreground">Stage</th><th className="text-right py-2 text-muted-foreground">Count</th><th className="text-right py-2 text-muted-foreground">Total Value</th></tr></thead><tbody>{pipelineData.map(r => <tr key={r.stage} className="border-b last:border-0"><td className="py-2 flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full" style={{background:STAGE_COLORS[r.stage]}} />{r.stage}</td><td className="py-2 text-right font-mono">{r.count}</td><td className="py-2 text-right font-mono">{formatCurrency(r.value)}</td></tr>)}</tbody></table></CardContent></Card>
          </div>
        )}

        {activeReport === 'summary' && (
          <Card><CardContent className="p-6"><table className="w-full text-sm"><thead><tr className="border-b"><th className="text-left py-2 text-muted-foreground">Stage</th><th className="text-right py-2 text-muted-foreground">Count</th><th className="text-right py-2 text-muted-foreground">Total Value</th><th className="text-right py-2 text-muted-foreground">Avg Probability</th></tr></thead><tbody>{oppSummary.map(r => <tr key={r.stage} className="border-b last:border-0"><td className="py-2 font-medium">{r.stage}</td><td className="py-2 text-right">{r.count}</td><td className="py-2 text-right font-mono">{formatCurrency(r.value)}</td><td className="py-2 text-right">{r.avgProb.toFixed(0)}%</td></tr>)}</tbody></table></CardContent></Card>
        )}

        {activeReport === 'engaged' && (
          <Card><CardContent className="p-6"><p className="text-sm text-muted-foreground mb-3">{notConverted.length} leads engaged for 30+ days without conversion</p><table className="w-full text-sm"><thead><tr className="border-b"><th className="text-left py-2 text-muted-foreground">Name</th><th className="text-left py-2 text-muted-foreground">Status</th><th className="text-left py-2 text-muted-foreground">Salesperson</th><th className="text-left py-2 text-muted-foreground">Created</th></tr></thead><tbody>{notConverted.map(l => <tr key={l.id} className="border-b last:border-0"><td className="py-2 font-medium">{l.name}</td><td className="py-2"><Badge variant="outline">{l.status}</Badge></td><td className="py-2">{l.assignedSalesperson}</td><td className="py-2 text-muted-foreground text-xs">{formatDate(l.createdAt)}</td></tr>)}</tbody></table></CardContent></Card>
        )}

        {activeReport === 'response' && (
          <Card><CardHeader><CardTitle className="text-base">Avg Days to First Update by Salesperson</CardTitle></CardHeader>
            <CardContent className="p-6 pt-0">
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={responseData} layout="vertical"><CartesianGrid strokeDasharray="3 3" horizontal={false} />
                  <XAxis type="number" tick={{ fontSize: 11 }} /><YAxis type="category" dataKey="name" tick={{ fontSize: 12 }} width={60} />
                  <Tooltip formatter={(v) => [`${v} days`, 'Avg Response']} />
                  <Bar dataKey="avgDays" fill="#6366f1" radius={[0,4,4,0]} /></BarChart>
              </ResponsiveContainer>
            </CardContent></Card>
        )}

        {activeReport === 'inactive' && (
          <Card><CardContent className="p-6"><p className="text-sm text-muted-foreground mb-3">{inactiveCustomers.length} customers inactive for 180+ days</p><table className="w-full text-sm"><thead><tr className="border-b"><th className="text-left py-2 text-muted-foreground">Name</th><th className="text-left py-2 text-muted-foreground">Group</th><th className="text-left py-2 text-muted-foreground">Territory</th><th className="text-left py-2 text-muted-foreground">Last Active</th></tr></thead><tbody>{inactiveCustomers.map(c => <tr key={c.id} className="border-b last:border-0"><td className="py-2 font-medium">{c.name}</td><td className="py-2">{c.group}</td><td className="py-2">{c.territory}</td><td className="py-2 text-muted-foreground text-xs">{formatDate(c.updatedAt)}</td></tr>)}</tbody></table></CardContent></Card>
        )}

        {activeReport === 'campaign' && (
          <Card><CardContent className="p-6"><table className="w-full text-sm"><thead><tr className="border-b"><th className="text-left py-2 text-muted-foreground">Campaign</th><th className="text-right py-2 text-muted-foreground">Conv Rate</th><th className="text-right py-2 text-muted-foreground">Cost/Lead</th><th className="text-right py-2 text-muted-foreground">Revenue</th></tr></thead><tbody>{campaignEff.map((c,i) => <tr key={i} className="border-b last:border-0"><td className="py-2 font-medium">{c.name}</td><td className="py-2 text-right">{c.convRate}%</td><td className="py-2 text-right font-mono">{formatCurrency(c.costPerLead)}</td><td className="py-2 text-right font-mono">{formatCurrency(c.revenue)}</td></tr>)}</tbody></table></CardContent></Card>
        )}

        {activeReport === 'owner' && (
          <Card><CardContent className="p-6"><table className="w-full text-sm"><thead><tr className="border-b"><th className="text-left py-2 text-muted-foreground">Salesperson</th><th className="text-right py-2 text-muted-foreground">Total Opps</th><th className="text-right py-2 text-muted-foreground">Win Rate</th><th className="text-right py-2 text-muted-foreground">Won Value</th></tr></thead><tbody>{ownerEff.map((r,i) => <tr key={i} className="border-b last:border-0"><td className="py-2 font-medium">{r.name}</td><td className="py-2 text-right">{r.total}</td><td className="py-2 text-right">{r.winRate}%</td><td className="py-2 text-right font-mono">{formatCurrency(r.value)}</td></tr>)}</tbody></table></CardContent></Card>
        )}
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-bold">Reports & Analytics</h1>

      <Tabs defaultValue="standard">
        <TabsList>
          <TabsTrigger value="standard">Standard Reports</TabsTrigger>
          <TabsTrigger value="custom">Custom Reports</TabsTrigger>
          <TabsTrigger value="territory">Territory Wise Sales</TabsTrigger>
        </TabsList>

        <TabsContent value="standard" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {REPORTS.map(r => (
              <Card key={r.id} className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveReport(r.id)}>
                <CardContent className="p-6 flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <r.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold text-sm">{r.title}</p>
                    <p className="text-xs text-muted-foreground mt-1">{r.description}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="custom" className="mt-4 space-y-4">
          <div className="flex flex-wrap gap-2">
            {VERTICAL_WINNING.map((v, i) => (
              <Button key={i} type="button" size="sm" variant={customVertical === i ? 'default' : 'outline'} onClick={() => setCustomVertical(i)}>
                {v.name}
              </Button>
            ))}
          </div>
          <div className="flex gap-2">
            <Button type="button" size="sm" variant={customView === 'monthly' ? 'default' : 'outline'} onClick={() => setCustomView('monthly')}>Monthly</Button>
            <Button type="button" size="sm" variant={customView === 'yearly' ? 'default' : 'outline'} onClick={() => setCustomView('yearly')}>Yearly</Button>
          </div>
          <Card>
            <CardHeader><CardTitle className="text-base">{vertData.name} – Winning % ({customView})</CardTitle></CardHeader>
            <CardContent className="p-6 pt-0">
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={chartData}><CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} /><YAxis tick={{ fontSize: 11 }} unit="%" domain={[0,100]} />
                  <Tooltip formatter={(v) => [`${v}%`, 'Winning %']} />
                  <Bar dataKey="winning" fill="#6366f1" radius={[4,4,0,0]} /></BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
          <Card><CardContent className="p-6">
            <table className="w-full text-sm"><thead><tr className="border-b"><th className="text-left py-2 text-muted-foreground">Period</th><th className="text-right py-2 text-muted-foreground">Winning %</th></tr></thead>
              <tbody>{chartData.map((r, i) => <tr key={i} className="border-b last:border-0"><td className="py-2">{r.name}</td><td className="py-2 text-right font-semibold">{r.winning}%</td></tr>)}</tbody>
            </table>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="territory" className="mt-4 space-y-4">
          <div className="flex flex-wrap gap-2">
            {TERRITORIES.map(t => (
              <Button key={t} type="button" size="sm"
                variant={territoryFilter.includes(t) ? 'default' : 'outline'}
                onClick={() => setTerritoryFilter(prev => prev.includes(t) ? prev.filter(x => x !== t) : [...prev, t])}>
                {t}
              </Button>
            ))}
          </div>
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            <Card><CardHeader><CardTitle className="text-base">Won Revenue by Territory</CardTitle></CardHeader>
              <CardContent className="p-6 pt-0">
                <ResponsiveContainer width="100%" height={240}>
                  <BarChart data={territoryData}><CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="territory" tick={{ fontSize: 12 }} /><YAxis tick={{ fontSize: 11 }} tickFormatter={v => `$${(v/1000).toFixed(0)}k`} />
                    <Tooltip formatter={(v) => [formatCurrency(v as number), 'Revenue']} />
                    <Bar dataKey="revenue" fill="#10b981" radius={[4,4,0,0]} /></BarChart>
                </ResponsiveContainer>
              </CardContent></Card>
            <Card><CardContent className="p-6">
              <table className="w-full text-sm"><thead><tr className="border-b"><th className="text-left py-2 text-muted-foreground">Territory</th><th className="text-right py-2 text-muted-foreground">Won Revenue</th><th className="text-right py-2 text-muted-foreground">Conversion %</th></tr></thead>
                <tbody>{territoryData.map(r => <tr key={r.territory} className="border-b last:border-0"><td className="py-2 font-medium">{r.territory}</td><td className="py-2 text-right font-mono">{formatCurrency(r.revenue)}</td><td className="py-2 text-right">{r.convRate}%</td></tr>)}</tbody>
              </table>
            </CardContent></Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
