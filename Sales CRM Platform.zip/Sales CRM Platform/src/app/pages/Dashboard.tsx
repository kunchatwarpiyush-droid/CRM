import { useMemo } from 'react';
import { useCRM } from '@/app/context/CRMContext';
import { KpiCard } from '@/app/components/KpiCard';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Users, TrendingUp, UserCheck, Activity, Loader2 } from 'lucide-react';
import { formatCurrency } from '@/app/utils/format';
import { VERTICAL_WINNING, SALESPERSONS } from '@/app/data/mockData';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  Cell, Legend
} from 'recharts';

const STAGE_COLORS: Record<string, string> = {
  New: '#3b82f6', Contacted: '#eab308', Qualified: '#22c55e',
  Proposal: '#a855f7', Negotiation: '#f97316', Won: '#10b981', Lost: '#ef4444'
};

export function Dashboard() {
  const { leads, opportunities, customers, leadsLoading, oppsLoading, custLoading } = useCRM();
  const isLoading = leadsLoading || oppsLoading || custLoading;

  const kpis = useMemo(() => {
    const openLeads = leads.filter(l => !['Won', 'Lost'].includes(l.status)).length;
    const opps = opportunities.length;
    return { totalLeads: leads.length, openLeads, opportunities: opps, customers: 1178 + customers.filter(c => c.id.startsWith('C0')).length };
  }, [leads, opportunities, customers]);

  const verticalData = useMemo(() =>
    VERTICAL_WINNING.map(v => ({ name: v.name.replace('Security & Surveillance', 'Security'), winning: v.yearly[0] })),
    []
  );

  const salespersonData = useMemo(() => {
    return SALESPERSONS.map(sp => {
      const total = opportunities.filter(o => o.assignedSalesperson === sp && !['Won', 'Lost'].includes(o.stage))
        .reduce((s, o) => s + o.dealValue, 0);
      return { name: sp.split(' ')[0], pipeline: total };
    });
  }, [opportunities]);

  const stageSummary = useMemo(() => {
    const stages = ['New', 'Qualified', 'Proposal', 'Negotiation', 'Won', 'Lost'];
    return stages.map(stage => ({
      stage,
      count: opportunities.filter(o => o.stage === stage).length,
      value: opportunities.filter(o => o.stage === stage).reduce((s, o) => s + o.dealValue, 0),
    })).filter(x => x.count > 0);
  }, [opportunities]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground text-sm mt-0.5">Sales overview and key metrics</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard title="Total Leads" value={kpis.totalLeads} sub="All time" icon={Users} color="bg-blue-500" />
        <KpiCard title="Open Leads" value={kpis.openLeads} sub="Active pipeline" icon={Activity} color="bg-orange-500" />
        <KpiCard title="Opportunities" value={kpis.opportunities} sub="Tracked deals" icon={TrendingUp} color="bg-purple-500" />
        <KpiCard title="Customers" value={kpis.customers.toLocaleString()} sub="Total accounts" icon={UserCheck} color="bg-green-500" />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Vertical Wise Sales */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Vertical Wise Winning %</CardTitle>
          </CardHeader>
          <CardContent className="p-6 pt-0">
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={verticalData} margin={{ top: 5, right: 10, left: 0, bottom: 60 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} angle={-35} textAnchor="end" interval={0} />
                <YAxis tick={{ fontSize: 11 }} unit="%" domain={[0, 100]} />
                <Tooltip formatter={(v) => [`${v}%`, 'Winning %']} />
                <Bar dataKey="winning" fill="#6366f1" radius={[4, 4, 0, 0]}>
                  {verticalData.map((_, i) => (
                    <Cell key={i} fill={['#6366f1','#8b5cf6','#a78bfa','#3b82f6','#06b6d4','#10b981','#f59e0b'][i % 7]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Salesperson Pipeline */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Salesperson Pipeline (Open Deals)</CardTitle>
          </CardHeader>
          <CardContent className="p-6 pt-0">
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={salespersonData} layout="vertical" margin={{ top: 5, right: 30, left: 10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11 }} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 12 }} width={55} />
                <Tooltip formatter={(v) => [formatCurrency(v as number), 'Pipeline Value']} />
                <Bar dataKey="pipeline" fill="#10b981" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Stage Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Pipeline by Stage</CardTitle>
        </CardHeader>
        <CardContent className="p-6 pt-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2 font-medium text-muted-foreground">Stage</th>
                  <th className="text-right py-2 font-medium text-muted-foreground">Count</th>
                  <th className="text-right py-2 font-medium text-muted-foreground">Total Value</th>
                  <th className="text-left py-2 pl-4 font-medium text-muted-foreground">Distribution</th>
                </tr>
              </thead>
              <tbody>
                {stageSummary.map(row => (
                  <tr key={row.stage} className="border-b last:border-0">
                    <td className="py-2">
                      <span className="inline-flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full" style={{ backgroundColor: STAGE_COLORS[row.stage] }} />
                        {row.stage}
                      </span>
                    </td>
                    <td className="py-2 text-right font-mono">{row.count}</td>
                    <td className="py-2 text-right font-mono">{formatCurrency(row.value)}</td>
                    <td className="py-2 pl-4">
                      <div className="w-32 h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{ width: `${Math.min(100, (row.value / 200000) * 100)}%`, backgroundColor: STAGE_COLORS[row.stage] }}
                        />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
