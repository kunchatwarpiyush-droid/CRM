import { useState } from 'react';
import { useCRM } from '@/app/context/CRMContext';
import { MasterItem } from '@/app/data/mockData';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ConfirmDialog } from '@/app/components/ConfirmDialog';
import { Pencil, Trash2, Plus, Check, X } from 'lucide-react';

interface MasterOps { add: (name: string) => Promise<void>; update: (id: string, name: string) => Promise<void>; remove: (id: string) => Promise<void>; }

function MasterList({ items, ops, label }: { items: MasterItem[]; ops: MasterOps; label: string }) {
  const { toast } = useToast();
  const [newName, setNewName] = useState('');
  const [editId, setEditId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<MasterItem | null>(null);

  const handleAdd = async () => {
    if (!newName.trim()) return;
    await ops.add(newName.trim());
    setNewName('');
    toast({ description: `${label} added` });
  };

  const handleUpdate = async () => {
    if (!editId || !editName.trim()) return;
    await ops.update(editId, editName.trim());
    setEditId(null);
    toast({ description: `${label} updated` });
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    await ops.remove(deleteTarget.id);
    setDeleteTarget(null);
    toast({ description: `${label} deleted`, variant: 'destructive' });
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Input className="h-8 text-sm" placeholder={`Add new ${label}…`} value={newName} onChange={e => setNewName(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleAdd()} />
        <Button type="button" size="sm" className="h-8 gap-1" onClick={handleAdd}><Plus className="w-3.5 h-3.5" />Add</Button>
      </div>
      <div className="rounded-md border divide-y">
        {items.length === 0 && <p className="text-sm text-muted-foreground text-center py-6">No {label.toLowerCase()} entries.</p>}
        {items.map(item => (
          <div key={item.id} className="flex items-center gap-2 px-3 py-2">
            {editId === item.id ? (
              <>
                <Input className="h-7 text-sm flex-1" value={editName} onChange={e => setEditName(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleUpdate()} autoFocus />
                <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0 text-green-600" onClick={handleUpdate}><Check className="w-4 h-4" /></Button>
                <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => setEditId(null)}><X className="w-4 h-4" /></Button>
              </>
            ) : (
              <>
                <span className="flex-1 text-sm">{item.name}</span>
                <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => { setEditId(item.id); setEditName(item.name); }}><Pencil className="w-3.5 h-3.5" /></Button>
                <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => setDeleteTarget(item)}><Trash2 className="w-3.5 h-3.5" /></Button>
              </>
            )}
          </div>
        ))}
      </div>
      <ConfirmDialog open={!!deleteTarget} title={`Delete ${label}`} description={`Delete "${deleteTarget?.name}"?`}
        onConfirm={handleDelete} onCancel={() => setDeleteTarget(null)} />
    </div>
  );
}

export function MasterDataPage() {
  const { territories, customerGroups, salesStages, leadSources, salesPersons,
    territoryOps, customerGroupOps, salesStageOps, leadSourceOps, salesPersonOps } = useCRM();

  return (
    <div className="p-6 space-y-4">
      <div><h1 className="text-2xl font-bold">Master Data</h1><p className="text-muted-foreground text-sm">Admin-only configuration</p></div>
      <Tabs defaultValue="territory">
        <TabsList className="flex-wrap h-auto gap-1">
          <TabsTrigger value="territory">Territory</TabsTrigger>
          <TabsTrigger value="group">Customer Group</TabsTrigger>
          <TabsTrigger value="stage">Sales Stage</TabsTrigger>
          <TabsTrigger value="source">Lead Source</TabsTrigger>
          <TabsTrigger value="person">Sales Person</TabsTrigger>
        </TabsList>
        <TabsContent value="territory" className="mt-4">
          <Card><CardContent className="p-6"><MasterList items={territories} ops={territoryOps} label="Territory" /></CardContent></Card>
        </TabsContent>
        <TabsContent value="group" className="mt-4">
          <Card><CardContent className="p-6"><MasterList items={customerGroups} ops={customerGroupOps} label="Customer Group" /></CardContent></Card>
        </TabsContent>
        <TabsContent value="stage" className="mt-4">
          <Card><CardContent className="p-6"><MasterList items={salesStages} ops={salesStageOps} label="Sales Stage" /></CardContent></Card>
        </TabsContent>
        <TabsContent value="source" className="mt-4">
          <Card><CardContent className="p-6"><MasterList items={leadSources} ops={leadSourceOps} label="Lead Source" /></CardContent></Card>
        </TabsContent>
        <TabsContent value="person" className="mt-4">
          <Card><CardContent className="p-6"><MasterList items={salesPersons} ops={salesPersonOps} label="Sales Person" /></CardContent></Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
