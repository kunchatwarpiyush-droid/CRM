import { useState } from 'react';
import { useCRM } from '@/app/context/CRMContext';
import { Lead, LeadStatus, LeadSource, Territory } from '@/app/data/mockData';
import { DataTable } from '@/app/components/DataTable';
import { StatusBadge } from '@/app/components/StatusBadge';
import { ConfirmDialog } from '@/app/components/ConfirmDialog';
import { SelectFilter } from '@/app/components/SelectFilter';
import { exportToCSV } from '@/app/utils/csv';
import { formatDate } from '@/app/utils/format';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Plus, Pencil, Trash2, MessageSquare, X } from 'lucide-react';

const STATUSES: LeadStatus[] = ['New', 'Contacted', 'Qualified', 'Proposal', 'Negotiation', 'Won', 'Lost'];
const SOURCES: LeadSource[] = ['Website', 'Referral', 'Cold Call', 'Email Campaign', 'Trade Show', 'Social Media', 'Partner'];
const TERRITORIES: Territory[] = ['North', 'South', 'East', 'West', 'Central', 'International'];

const EMPTY: Omit<Lead, 'id' | 'createdAt' | 'updatedAt' | 'comments'> = {
  name: '', phone: '', email: '', leadSource: 'Website', territory: 'North', assignedSalesperson: '', status: 'New'
};

export function LeadsPage() {
  const { leads, addLead, updateLead, deleteLead, addLeadComment, salesPersons } = useCRM();
  const { toast } = useToast();

  const [statusFilter, setStatusFilter] = useState('all');
  const [territoryFilter, setTerritoryFilter] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editLead, setEditLead] = useState<Lead | null>(null);
  const [form, setForm] = useState({ ...EMPTY });
  const [deleteTarget, setDeleteTarget] = useState<Lead | null>(null);
  const [detailLead, setDetailLead] = useState<Lead | null>(null);
  const [comment, setComment] = useState('');

  const filtered = leads.filter(l => {
    if (statusFilter !== 'all' && l.status !== statusFilter) return false;
    if (territoryFilter !== 'all' && l.territory !== territoryFilter) return false;
    return true;
  });

  const openAdd = () => { setEditLead(null); setForm({ ...EMPTY }); setModalOpen(true); };
  const openEdit = (l: Lead) => { setEditLead(l); setForm({ name: l.name, phone: l.phone, email: l.email, leadSource: l.leadSource, territory: l.territory, assignedSalesperson: l.assignedSalesperson, status: l.status }); setModalOpen(true); };

  const handleSubmit = async () => {
    if (!form.name.trim()) return;
    if (editLead) {
      await updateLead(editLead.id, form);
      toast({ title: 'Lead updated', description: form.name });
    } else {
      await addLead(form);
      toast({ title: 'Lead created', description: form.name });
    }
    setModalOpen(false);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    await deleteLead(deleteTarget.id);
    toast({ title: 'Lead deleted', variant: 'destructive' });
    setDeleteTarget(null);
    if (detailLead?.id === deleteTarget.id) setDetailLead(null);
  };

  const handleAddComment = async () => {
    if (!comment.trim() || !detailLead) return;
    await addLeadComment(detailLead.id, comment, 'You');
    setComment('');
    toast({ description: 'Comment added' });
  };

  const spNames = salesPersons.length ? salesPersons.map(s => s.name) : ['Alice Johnson', 'Bob Martinez', 'Carol Lee', 'David Kim', 'Emma Wilson'];

  const columns = [
    { key: 'name', label: 'Name', render: (r: Lead) => <span className="font-medium">{r.name}</span> },
    { key: 'phone', label: 'Phone' },
    { key: 'email', label: 'Email' },
    { key: 'leadSource', label: 'Source' },
    { key: 'territory', label: 'Territory' },
    { key: 'assignedSalesperson', label: 'Salesperson' },
    { key: 'status', label: 'Status', render: (r: Lead) => <StatusBadge status={r.status} /> },
    { key: 'createdAt', label: 'Created', render: (r: Lead) => <span className="text-muted-foreground text-xs">{formatDate(r.createdAt)}</span> },
  ];

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Leads</h1>
          <p className="text-muted-foreground text-sm">{leads.length} total leads</p>
        </div>
        <Button size="sm" className="gap-1.5" onClick={openAdd}><Plus className="w-4 h-4" />Add Lead</Button>
      </div>

      <Card>
        <CardContent className="p-6">
          <DataTable<Lead>
            data={filtered}
            columns={columns}
            searchKeys={['name', 'email', 'assignedSalesperson']}
            onExport={() => exportToCSV(filtered.map(({ comments: _c, ...r }) => r), 'leads')}
            extraFilters={
              <>
                <SelectFilter value={statusFilter} onValueChange={v => setStatusFilter(v)} placeholder="All Statuses"
                  options={STATUSES.map(s => ({ label: s, value: s }))} />
                <SelectFilter value={territoryFilter} onValueChange={v => setTerritoryFilter(v)} placeholder="All Territories"
                  options={TERRITORIES.map(t => ({ label: t, value: t }))} />
              </>
            }
            actions={(l: Lead) => {
              return (
                <div className="flex items-center gap-1 justify-end">
                  <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => setDetailLead(l)}>
                    <MessageSquare className="w-3.5 h-3.5" />
                  </Button>
                  <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => openEdit(l)}>
                    <Pencil className="w-3.5 h-3.5" />
                  </Button>
                  <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => setDeleteTarget(l)}>
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              );
          }}
          />
        </CardContent>
      </Card>

      {/* Add/Edit Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editLead ? 'Edit Lead' : 'Add Lead'}</DialogTitle></DialogHeader>
          <div className="grid gap-3 py-2">
            <div className="grid gap-1.5">
              <Label>Name *</Label>
              <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Company or person name" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label>Phone</Label>
                <Input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="+1-555-0000" />
              </div>
              <div className="grid gap-1.5">
                <Label>Email</Label>
                <Input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="email@example.com" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label>Lead Source</Label>
                <Select value={form.leadSource} onValueChange={v => setForm(f => ({ ...f, leadSource: v as LeadSource }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{SOURCES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="grid gap-1.5">
                <Label>Territory</Label>
                <Select value={form.territory} onValueChange={v => setForm(f => ({ ...f, territory: v as Territory }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{TERRITORIES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label>Assigned Salesperson</Label>
                <Select value={form.assignedSalesperson || 'none'} onValueChange={v => setForm(f => ({ ...f, assignedSalesperson: v === 'none' ? '' : v }))}>
                  <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Unassigned</SelectItem>
                    {spNames.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-1.5">
                <Label>Status</Label>
                <Select value={form.status} onValueChange={v => setForm(f => ({ ...f, status: v as LeadStatus }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="button" onClick={handleSubmit}>{editLead ? 'Save Changes' : 'Create Lead'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete Lead"
        description={`Delete "${deleteTarget?.name}"? This cannot be undone.`}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      {/* Detail / Comments Panel */}
      {detailLead && (
        <div className="fixed inset-y-0 right-0 w-80 bg-card border-l shadow-xl z-50 flex flex-col">
          <div className="flex items-center justify-between p-4 border-b">
            <div>
              <p className="font-semibold">{detailLead.name}</p>
              <StatusBadge status={detailLead.status} />
            </div>
            <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => setDetailLead(null)}>
              <X className="w-4 h-4" />
            </Button>
          </div>
          <div className="p-4 text-sm space-y-1 text-muted-foreground border-b">
            <p><span className="font-medium text-foreground">Phone:</span> {detailLead.phone}</p>
            <p><span className="font-medium text-foreground">Email:</span> {detailLead.email}</p>
            <p><span className="font-medium text-foreground">Source:</span> {detailLead.leadSource}</p>
            <p><span className="font-medium text-foreground">Territory:</span> {detailLead.territory}</p>
            <p><span className="font-medium text-foreground">Assigned:</span> {detailLead.assignedSalesperson || 'Unassigned'}</p>
            <p><span className="font-medium text-foreground">Created:</span> {formatDate(detailLead.createdAt)}</p>
          </div>
          <div className="p-4 flex-1 flex flex-col gap-3 overflow-hidden">
            <p className="font-medium text-sm">Comments ({detailLead.comments?.length ?? 0})</p>
            <ScrollArea className="flex-1">
              {(detailLead.comments ?? []).length === 0
                ? <p className="text-xs text-muted-foreground">No comments yet.</p>
                : (detailLead.comments ?? []).map(c => (
                  <div key={c.id} className="mb-3">
                    <p className="text-xs font-medium">{c.author} <span className="text-muted-foreground font-normal">{formatDate(c.createdAt)}</span></p>
                    <p className="text-sm">{c.text}</p>
                    <Separator className="mt-2" />
                  </div>
                ))
              }
            </ScrollArea>
            <div className="grid gap-2">
              <Textarea
                className="text-sm resize-none"
                rows={2}
                placeholder="Add a comment…"
                value={comment}
                onChange={e => setComment(e.target.value)}
              />
              <Button type="button" size="sm" onClick={handleAddComment} disabled={!comment.trim()}>Add Comment</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
