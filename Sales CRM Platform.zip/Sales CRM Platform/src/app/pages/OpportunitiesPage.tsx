import { useState } from 'react';
import { useCRM } from '@/app/context/CRMContext';
import { Opportunity, LeadStatus } from '@/app/data/mockData';
import { DataTable } from '@/app/components/DataTable';
import { StatusBadge } from '@/app/components/StatusBadge';
import { ConfirmDialog } from '@/app/components/ConfirmDialog';
import { SelectFilter } from '@/app/components/SelectFilter';
import { exportToCSV } from '@/app/utils/csv';
import { formatDate, formatCurrency } from '@/app/utils/format';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Plus, Pencil, Trash2, MessageSquare, X } from 'lucide-react';

const STAGES: LeadStatus[] = ['New', 'Qualified', 'Proposal', 'Negotiation', 'Won', 'Lost'];

const EMPTY: Omit<Opportunity, 'id' | 'createdAt' | 'updatedAt' | 'comments'> = {
  linkedLeadId: '', linkedLeadName: '', dealValue: 0, stage: 'Qualified',
  probability: 50, expectedCloseDate: '', assignedSalesperson: ''
};

export function OpportunitiesPage() {
  const { opportunities, leads, addOpportunity, updateOpportunity, deleteOpportunity, addOppComment, salesPersons } = useCRM();
  const { toast } = useToast();

  const [stageFilter, setStageFilter] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editOpp, setEditOpp] = useState<Opportunity | null>(null);
  const [form, setForm] = useState({ ...EMPTY });
  const [deleteTarget, setDeleteTarget] = useState<Opportunity | null>(null);
  const [detailOpp, setDetailOpp] = useState<Opportunity | null>(null);
  const [comment, setComment] = useState('');

  const filtered = stageFilter === 'all' ? opportunities : opportunities.filter(o => o.stage === stageFilter);

  const openAdd = () => { setEditOpp(null); setForm({ ...EMPTY }); setModalOpen(true); };
  const openEdit = (o: Opportunity) => {
    setEditOpp(o);
    setForm({ linkedLeadId: o.linkedLeadId, linkedLeadName: o.linkedLeadName, dealValue: o.dealValue, stage: o.stage, probability: o.probability, expectedCloseDate: o.expectedCloseDate, assignedSalesperson: o.assignedSalesperson });
    setModalOpen(true);
  };

  const handleSubmit = async () => {
    if (editOpp) {
      await updateOpportunity(editOpp.id, form);
      toast({ title: 'Opportunity updated' });
    } else {
      await addOpportunity(form);
      toast({ title: 'Opportunity created' });
    }
    setModalOpen(false);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    await deleteOpportunity(deleteTarget.id);
    toast({ title: 'Opportunity deleted', variant: 'destructive' });
    setDeleteTarget(null);
  };

  const handleAddComment = async () => {
    if (!comment.trim() || !detailOpp) return;
    await addOppComment(detailOpp.id, comment, 'You');
    setComment('');
    toast({ description: 'Comment added' });
  };

  const spNames = salesPersons.length ? salesPersons.map(s => s.name) : ['Alice Johnson', 'Bob Martinez', 'Carol Lee', 'David Kim', 'Emma Wilson'];

  const columns = [
    { key: 'linkedLeadName', label: 'Lead', render: (r: Opportunity) => <span className="font-medium">{r.linkedLeadName}</span> },
    { key: 'dealValue', label: 'Deal Value', render: (r: Opportunity) => <span className="font-mono">{formatCurrency(r.dealValue)}</span> },
    { key: 'stage', label: 'Stage', render: (r: Opportunity) => <StatusBadge status={r.stage} /> },
    { key: 'probability', label: 'Probability', render: (r: Opportunity) => <span>{r.probability}%</span> },
    { key: 'expectedCloseDate', label: 'Close Date', render: (r: Opportunity) => <span className="text-muted-foreground text-xs">{formatDate(r.expectedCloseDate)}</span> },
    { key: 'assignedSalesperson', label: 'Salesperson' },
    { key: 'createdAt', label: 'Created', render: (r: Opportunity) => <span className="text-muted-foreground text-xs">{formatDate(r.createdAt)}</span> },
  ];

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Opportunities</h1>
          <p className="text-muted-foreground text-sm">{opportunities.length} total opportunities</p>
        </div>
        <Button size="sm" className="gap-1.5" onClick={openAdd}><Plus className="w-4 h-4" />Add Opportunity</Button>
      </div>

      <Card><CardContent className="p-6">
        <DataTable
          data={filtered}
          columns={columns}
          searchKeys={['linkedLeadName', 'assignedSalesperson']}
          onExport={() => exportToCSV(filtered.map(({ comments: _c, ...r }) => r), 'opportunities')}
          extraFilters={
            <SelectFilter value={stageFilter} onValueChange={setStageFilter} placeholder="All Stages"
              options={STAGES.map(s => ({ label: s, value: s }))} />
          }
          actions={(o: Opportunity) => {
            return (
              <div className="flex items-center gap-1 justify-end">
                <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => setDetailOpp(o)}>
                  <MessageSquare className="w-3.5 h-3.5" />
                </Button>
                <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => openEdit(o)}>
                  <Pencil className="w-3.5 h-3.5" />
                </Button>
                <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => setDeleteTarget(o)}>
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </div>
            );
          }}
        />
      </CardContent></Card>

      {/* Add/Edit Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editOpp ? 'Edit Opportunity' : 'Add Opportunity'}</DialogTitle></DialogHeader>
          <div className="grid gap-3 py-2">
            <div className="grid gap-1.5">
              <Label>Linked Lead</Label>
              <Select value={form.linkedLeadId || 'none'} onValueChange={v => {
                const lead = leads.find(l => l.id === v);
                setForm(f => ({ ...f, linkedLeadId: v === 'none' ? '' : v, linkedLeadName: lead?.name ?? '' }));
              }}>
                <SelectTrigger><SelectValue placeholder="Select a lead…" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {leads.map(l => <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label>Deal Value ($)</Label>
                <Input type="number" min={0} value={form.dealValue} onChange={e => setForm(f => ({ ...f, dealValue: parseFloat(e.target.value) || 0 }))} />
              </div>
              <div className="grid gap-1.5">
                <Label>Probability (%)</Label>
                <Input type="number" min={0} max={100} value={form.probability} onChange={e => setForm(f => ({ ...f, probability: parseFloat(e.target.value) || 0 }))} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label>Stage</Label>
                <Select value={form.stage} onValueChange={v => setForm(f => ({ ...f, stage: v as LeadStatus }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{STAGES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="grid gap-1.5">
                <Label>Expected Close Date</Label>
                <Input type="date" value={form.expectedCloseDate} onChange={e => setForm(f => ({ ...f, expectedCloseDate: e.target.value }))} />
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label>Assigned Salesperson</Label>
              <Select value={form.assignedSalesperson || 'none'} onValueChange={v => setForm(f => ({ ...f, assignedSalesperson: v === 'none' ? '' : v }))}>
                <SelectTrigger><SelectValue placeholder="Select…" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Unassigned</SelectItem>
                  {spNames.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="button" onClick={handleSubmit}>{editOpp ? 'Save Changes' : 'Create Opportunity'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog open={!!deleteTarget} title="Delete Opportunity"
        description={`Delete opportunity for "${deleteTarget?.linkedLeadName}"?`}
        onConfirm={handleDelete} onCancel={() => setDeleteTarget(null)} />

      {/* Comments Panel */}
      {detailOpp && (
        <div className="fixed inset-y-0 right-0 w-80 bg-card border-l shadow-xl z-50 flex flex-col">
          <div className="flex items-center justify-between p-4 border-b">
            <div>
              <p className="font-semibold">{detailOpp.linkedLeadName}</p>
              <p className="text-sm text-muted-foreground">{formatCurrency(detailOpp.dealValue)} · <StatusBadge status={detailOpp.stage} /></p>
            </div>
            <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => setDetailOpp(null)}>
              <X className="w-4 h-4" />
            </Button>
          </div>
          <div className="p-4 flex-1 flex flex-col gap-3 overflow-hidden">
            <p className="font-medium text-sm">Comments ({detailOpp.comments?.length ?? 0})</p>
            <ScrollArea className="flex-1">
              {(detailOpp.comments ?? []).length === 0
                ? <p className="text-xs text-muted-foreground">No comments yet.</p>
                : (detailOpp.comments ?? []).map(c => (
                  <div key={c.id} className="mb-3">
                    <p className="text-xs font-medium">{c.author} <span className="text-muted-foreground font-normal">{formatDate(c.createdAt)}</span></p>
                    <p className="text-sm">{c.text}</p>
                    <Separator className="mt-2" />
                  </div>
                ))
              }
            </ScrollArea>
            <div className="grid gap-2">
              <Textarea className="text-sm resize-none" rows={2} placeholder="Add a comment…" value={comment} onChange={e => setComment(e.target.value)} />
              <Button type="button" size="sm" onClick={handleAddComment} disabled={!comment.trim()}>Add Comment</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
