import { useState } from 'react';
import { useCRM } from '@/app/context/CRMContext';
import { Communication, CommType } from '@/app/data/mockData';
import { DataTable } from '@/app/components/DataTable';
import { StatusBadge } from '@/app/components/StatusBadge';
import { ConfirmDialog } from '@/app/components/ConfirmDialog';
import { SelectFilter } from '@/app/components/SelectFilter';
import { exportToCSV } from '@/app/utils/csv';
import { formatDate } from '@/app/utils/format';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { Plus, Pencil, Trash2 } from 'lucide-react';

const TYPES: CommType[] = ['Call', 'Email', 'Follow-up'];
const EMPTY: Omit<Communication, 'id' | 'createdAt' | 'updatedAt'> = { type: 'Call', linkedTo: '', linkedType: 'Lead', subject: '', notes: '', date: '' };

export function CommunicationsPage() {
  const { communications, addCommunication, updateCommunication, deleteCommunication } = useCRM();
  const { toast } = useToast();

  const [typeFilter, setTypeFilter] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editItem, setEditItem] = useState<Communication | null>(null);
  const [form, setForm] = useState({ ...EMPTY });
  const [deleteTarget, setDeleteTarget] = useState<Communication | null>(null);

  const filtered = typeFilter === 'all' ? communications : communications.filter(c => c.type === typeFilter);

  const openAdd = () => { setEditItem(null); setForm({ ...EMPTY }); setModalOpen(true); };
  const openEdit = (c: Communication) => { setEditItem(c); setForm({ type: c.type, linkedTo: c.linkedTo, linkedType: c.linkedType, subject: c.subject, notes: c.notes, date: c.date }); setModalOpen(true); };

  const handleSubmit = async () => {
    if (!form.subject.trim()) return;
    if (editItem) { await updateCommunication(editItem.id, form); toast({ title: 'Log updated' }); }
    else { await addCommunication(form); toast({ title: 'Log entry created' }); }
    setModalOpen(false);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    await deleteCommunication(deleteTarget.id);
    toast({ title: 'Log entry deleted', variant: 'destructive' });
    setDeleteTarget(null);
  };

  const columns = [
    { key: 'type', label: 'Type', render: (r: Communication) => <StatusBadge status={r.type} /> },
    { key: 'linkedTo', label: 'Linked To', render: (r: Communication) => <span className="font-medium">{r.linkedTo}</span> },
    { key: 'linkedType', label: 'Type' },
    { key: 'subject', label: 'Subject' },
    { key: 'date', label: 'Date', render: (r: Communication) => <span className="text-xs text-muted-foreground">{formatDate(r.date)}</span> },
    { key: 'notes', label: 'Notes', render: (r: Communication) => <span className="text-xs text-muted-foreground truncate max-w-xs block">{r.notes}</span> },
  ];

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold">Communication Log</h1><p className="text-muted-foreground text-sm">{communications.length} entries</p></div>
        <Button size="sm" className="gap-1.5" onClick={openAdd}><Plus className="w-4 h-4" />Log Entry</Button>
      </div>
      <Card><CardContent className="p-6">
        <DataTable
          data={filtered}
          columns={columns}
          searchKeys={['linkedTo', 'subject', 'notes']}
          onExport={() => exportToCSV(filtered, 'communications')}
          extraFilters={
            <SelectFilter value={typeFilter} onValueChange={setTypeFilter} placeholder="All Types"
              options={TYPES.map(t => ({ label: t, value: t }))} />
          }
          actions={(c: Communication) => {
            return (
              <div className="flex items-center gap-1 justify-end">
                <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => openEdit(c)}><Pencil className="w-3.5 h-3.5" /></Button>
                <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => setDeleteTarget(c)}><Trash2 className="w-3.5 h-3.5" /></Button>
              </div>
            );
          }}
        />
      </CardContent></Card>

      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{editItem ? 'Edit Log Entry' : 'New Log Entry'}</DialogTitle></DialogHeader>
          <div className="grid gap-3 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label>Type</Label>
                <Select value={form.type} onValueChange={v => setForm(f => ({ ...f, type: v as CommType }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="grid gap-1.5">
                <Label>Linked Type</Label>
                <Select value={form.linkedType} onValueChange={v => setForm(f => ({ ...f, linkedType: v as 'Lead' | 'Customer' }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Lead">Lead</SelectItem>
                    <SelectItem value="Customer">Customer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-1.5"><Label>Linked To</Label><Input value={form.linkedTo} onChange={e => setForm(f => ({ ...f, linkedTo: e.target.value }))} placeholder="Lead or customer name" /></div>
            <div className="grid gap-1.5"><Label>Subject *</Label><Input value={form.subject} onChange={e => setForm(f => ({ ...f, subject: e.target.value }))} placeholder="Subject" /></div>
            <div className="grid gap-1.5"><Label>Date</Label><Input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} /></div>
            <div className="grid gap-1.5"><Label>Notes</Label><Textarea rows={3} value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} /></div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="button" onClick={handleSubmit}>{editItem ? 'Save' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <ConfirmDialog open={!!deleteTarget} title="Delete Log Entry" description={`Delete "${deleteTarget?.subject}"?`} onConfirm={handleDelete} onCancel={() => setDeleteTarget(null)} />
    </div>
  );
}
