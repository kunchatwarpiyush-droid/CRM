import { useState } from 'react';
import { useCRM } from '@/app/context/CRMContext';
import { Campaign } from '@/app/data/mockData';
import { DataTable } from '@/app/components/DataTable';
import { ConfirmDialog } from '@/app/components/ConfirmDialog';
import { exportToCSV } from '@/app/utils/csv';
import { formatDate, formatCurrency } from '@/app/utils/format';
import { useToast } from '@/hooks/use-toast';
import { KpiCard } from '@/app/components/KpiCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Plus, Pencil, Trash2, ChevronLeft, Target, Users, TrendingUp, DollarSign } from 'lucide-react';

const EMPTY: Omit<Campaign, 'id' | 'createdAt' | 'updatedAt'> = { name: '', startDate: '', endDate: '', target: 0, leadsGenerated: 0, conversions: 0, revenue: 0 };

export function CampaignsPage() {
  const { campaigns, addCampaign, updateCampaign, deleteCampaign } = useCRM();
  const { toast } = useToast();

  const [modalOpen, setModalOpen] = useState(false);
  const [editItem, setEditItem] = useState<Campaign | null>(null);
  const [form, setForm] = useState({ ...EMPTY });
  const [deleteTarget, setDeleteTarget] = useState<Campaign | null>(null);
  const [detailCampaign, setDetailCampaign] = useState<Campaign | null>(null);

  const openAdd = () => { setEditItem(null); setForm({ ...EMPTY }); setModalOpen(true); };
  const openEdit = (c: Campaign) => { setEditItem(c); setForm({ name: c.name, startDate: c.startDate, endDate: c.endDate, target: c.target, leadsGenerated: c.leadsGenerated, conversions: c.conversions, revenue: c.revenue }); setModalOpen(true); };

  const handleSubmit = async () => {
    if (!form.name.trim()) return;
    if (editItem) { await updateCampaign(editItem.id, form); toast({ title: 'Campaign updated' }); }
    else { await addCampaign(form); toast({ title: 'Campaign created' }); }
    setModalOpen(false);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    await deleteCampaign(deleteTarget.id);
    toast({ title: 'Campaign deleted', variant: 'destructive' });
    setDeleteTarget(null);
  };

  if (detailCampaign) {
    const convRate = detailCampaign.leadsGenerated > 0 ? Math.round((detailCampaign.conversions / detailCampaign.leadsGenerated) * 100) : 0;
    const chartData = [
      { month: 'Leads', value: detailCampaign.leadsGenerated },
      { month: 'Conversions', value: detailCampaign.conversions },
      { month: 'Target', value: detailCampaign.target },
    ];
    return (
      <div className="p-6 space-y-4">
        <div className="flex items-center gap-3">
          <Button type="button" size="sm" variant="ghost" onClick={() => setDetailCampaign(null)}><ChevronLeft className="w-4 h-4" /></Button>
          <div><h1 className="text-2xl font-bold">{detailCampaign.name}</h1>
            <p className="text-muted-foreground text-sm">{formatDate(detailCampaign.startDate)} – {formatDate(detailCampaign.endDate)}</p></div>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <KpiCard title="Leads Generated" value={detailCampaign.leadsGenerated} icon={Users} color="bg-blue-500" />
          <KpiCard title="Conversions" value={detailCampaign.conversions} icon={Target} color="bg-green-500" />
          <KpiCard title="Revenue" value={formatCurrency(detailCampaign.revenue)} icon={DollarSign} color="bg-purple-500" />
          <KpiCard title="Conversion Rate" value={`${convRate}%`} icon={TrendingUp} color="bg-orange-500" />
        </div>
        <Card><CardHeader><CardTitle className="text-base">Performance</CardTitle></CardHeader>
          <CardContent className="p-6 pt-0">
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={chartData}><CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} /><YAxis tick={{ fontSize: 11 }} />
                <Tooltip /><Bar dataKey="value" fill="#6366f1" radius={[4,4,0,0]} /></BarChart>
            </ResponsiveContainer>
          </CardContent></Card>
      </div>
    );
  }

  const columns = [
    { key: 'name', label: 'Name', render: (r: Campaign) => <span className="font-medium">{r.name}</span> },
    { key: 'startDate', label: 'Start', render: (r: Campaign) => <span>{formatDate(r.startDate)}</span> },
    { key: 'endDate', label: 'End', render: (r: Campaign) => <span>{formatDate(r.endDate)}</span> },
    { key: 'target', label: 'Target' },
    { key: 'leadsGenerated', label: 'Leads' },
    { key: 'conversions', label: 'Conversions' },
    { key: 'revenue', label: 'Revenue', render: (r: Campaign) => <span className="font-mono">{formatCurrency(r.revenue)}</span> },
  ];

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold">Campaigns</h1><p className="text-muted-foreground text-sm">{campaigns.length} campaigns</p></div>
        <Button size="sm" className="gap-1.5" onClick={openAdd}><Plus className="w-4 h-4" />New Campaign</Button>
      </div>
      <Card><CardContent className="p-6">
        <DataTable<Campaign> data={campaigns} columns={columns}
          searchKeys={['name']} onExport={() => exportToCSV(campaigns, 'campaigns')}
          onRowClick={row => setDetailCampaign(row)}
          actions={(c: Campaign) => {
            return (
              <div className="flex items-center gap-1 justify-end">
                <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => openEdit(c)}><Pencil className="w-3.5 h-3.5" /></Button>
                <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => setDeleteTarget(c)}><Trash2 className="w-3.5 h-3.5" /></Button>
              </div>
            );
          }}
        />
      </CardContent></Card>

      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{editItem ? 'Edit Campaign' : 'New Campaign'}</DialogTitle></DialogHeader>
          <div className="grid gap-3 py-2">
            <div className="grid gap-1.5"><Label>Name *</Label><Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5"><Label>Start Date</Label><Input type="date" value={form.startDate} onChange={e => setForm(f => ({ ...f, startDate: e.target.value }))} /></div>
              <div className="grid gap-1.5"><Label>End Date</Label><Input type="date" value={form.endDate} onChange={e => setForm(f => ({ ...f, endDate: e.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5"><Label>Target Leads</Label><Input type="number" min={0} value={form.target} onChange={e => setForm(f => ({ ...f, target: parseInt(e.target.value) || 0 }))} /></div>
              <div className="grid gap-1.5"><Label>Leads Generated</Label><Input type="number" min={0} value={form.leadsGenerated} onChange={e => setForm(f => ({ ...f, leadsGenerated: parseInt(e.target.value) || 0 }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5"><Label>Conversions</Label><Input type="number" min={0} value={form.conversions} onChange={e => setForm(f => ({ ...f, conversions: parseInt(e.target.value) || 0 }))} /></div>
              <div className="grid gap-1.5"><Label>Revenue ($)</Label><Input type="number" min={0} value={form.revenue} onChange={e => setForm(f => ({ ...f, revenue: parseFloat(e.target.value) || 0 }))} /></div>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="button" onClick={handleSubmit}>{editItem ? 'Save' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <ConfirmDialog open={!!deleteTarget} title="Delete Campaign" description={`Delete "${deleteTarget?.name}"?`} onConfirm={handleDelete} onCancel={() => setDeleteTarget(null)} />
    </div>
  );
}
