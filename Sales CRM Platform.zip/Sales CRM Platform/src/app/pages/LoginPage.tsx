import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Building2, AlertCircle, Loader2 } from 'lucide-react';
import { useLoadAction } from '@uibakery/data';
import gsGetAction from '@/actions/gsGet';

interface Props { onLogin: (user: { name: string; role: 'Admin' | 'Salesperson' }) => void; }

export function LoginPage({ onLogin }: Props) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const [users, usersLoading] = useLoadAction(gsGetAction, [], { sheet: 'Users' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (usersLoading) return;
    setLoading(true);
    setError('');

    const rows = (users as Record<string, string>[]);
    const match = rows.find(
      u => u.username?.toLowerCase() === username.toLowerCase() && u.password === password
    );

    if (match) {
      onLogin({ name: match.name || match.username, role: (match.role as 'Admin' | 'Salesperson') || 'Salesperson' });
    } else {
      setError('Invalid username or password');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/40">
      <div className="w-full max-w-sm px-4">
        <div className="flex justify-center mb-6">
          <div className="flex items-center gap-2">
            <Building2 className="w-8 h-8 text-primary" />
            <span className="text-2xl font-bold">SalesCRM</span>
          </div>
        </div>
        <Card>
          <CardHeader>
            <CardTitle className="text-center text-lg">Sign in to your account</CardTitle>
          </CardHeader>
          <CardContent className="p-6 pt-0">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="username">Username</Label>
                <Input id="username" value={username} onChange={e => setUsername(e.target.value)} placeholder="Enter username" required />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="password">Password</Label>
                <Input id="password" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required />
              </div>
              {error && (
                <div className="flex items-center gap-2 text-destructive text-sm">
                  <AlertCircle className="w-4 h-4" /> {error}
                </div>
              )}
              <Button type="submit" className="w-full" disabled={loading || usersLoading}>
                {loading || usersLoading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Please wait…</> : 'Sign In'}
              </Button>
            </form>
            <p className="text-xs text-muted-foreground text-center mt-4">
              Credentials are validated against your Google Sheet Users tab.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
