import { useState } from 'react';
import { useCRM } from '@/app/context/CRMContext';
import { Customer, CustomerGroup, Territory } from '@/app/data/mockData';
import { DataTable } from '@/app/components/DataTable';
import { ConfirmDialog } from '@/app/components/ConfirmDialog';
import { SelectFilter } from '@/app/components/SelectFilter';
import { exportToCSV } from '@/app/utils/csv';
import { formatDate } from '@/app/utils/format';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { Plus, Pencil, Trash2 } from 'lucide-react';

const GROUPS: CustomerGroup[] = ['Enterprise', 'SMB', 'Startup', 'Government', 'Education'];
const TERRITORIES: Territory[] = ['North', 'South', 'East', 'West', 'Central', 'International'];
const EMPTY: Omit<Customer, 'id' | 'createdAt' | 'updatedAt'> = { name: '', contact: '', group: 'Enterprise', territory: 'North' };

export function CustomersPage() {
  const { customers, addCustomer, updateCustomer, deleteCustomer } = useCRM();
  const { toast } = useToast();

  const [groupFilter, setGroupFilter] = useState('all');
  const [territoryFilter, setTerritoryFilter] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editCustomer, setEditCustomer] = useState<Customer | null>(null);
  const [form, setForm] = useState({ ...EMPTY });
  const [deleteTarget, setDeleteTarget] = useState<Customer | null>(null);

  const filtered = customers.filter(c => {
    if (groupFilter !== 'all' && c.group !== groupFilter) return false;
    if (territoryFilter !== 'all' && c.territory !== territoryFilter) return false;
    return true;
  });

  const openAdd = () => { setEditCustomer(null); setForm({ ...EMPTY }); setModalOpen(true); };
  const openEdit = (c: Customer) => { setEditCustomer(c); setForm({ name: c.name, contact: c.contact, group: c.group, territory: c.territory }); setModalOpen(true); };

  const handleSubmit = async () => {
    if (!form.name.trim()) return;
    if (editCustomer) {
      await updateCustomer(editCustomer.id, form);
      toast({ title: 'Customer updated' });
    } else {
      await addCustomer(form);
      toast({ title: 'Customer created' });
    }
    setModalOpen(false);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    await deleteCustomer(deleteTarget.id);
    toast({ title: 'Customer deleted', variant: 'destructive' });
    setDeleteTarget(null);
  };

  const columns = [
    { key: 'name', label: 'Name', render: (r: Customer) => <span className="font-medium">{r.name}</span> },
    { key: 'contact', label: 'Contact' },
    { key: 'group', label: 'Group', render: (r: Customer) => (
      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">{r.group}</span>
    )},
    { key: 'territory', label: 'Territory' },
    { key: 'createdAt', label: 'Created', render: (r: Customer) => <span className="text-muted-foreground text-xs">{formatDate(r.createdAt)}</span> },
  ];

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Customers</h1>
          <p className="text-muted-foreground text-sm">{customers.length} records shown (1,178 total)</p>
        </div>
        <Button size="sm" className="gap-1.5" onClick={openAdd}><Plus className="w-4 h-4" />Add Customer</Button>
      </div>

      <Card><CardContent className="p-6">
        <DataTable
          data={filtered}
          columns={columns}
          searchKeys={['name', 'contact']}
          onExport={() => exportToCSV(filtered, 'customers')}
          extraFilters={
            <>
              <SelectFilter value={groupFilter} onValueChange={setGroupFilter} placeholder="All Groups" options={GROUPS.map(g => ({ label: g, value: g }))} />
              <SelectFilter value={territoryFilter} onValueChange={setTerritoryFilter} placeholder="All Territories" options={TERRITORIES.map(t => ({ label: t, value: t }))} />
            </>
          }
          actions={(c: Customer) => {
            return (
              <div className="flex items-center gap-1 justify-end">
                <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => openEdit(c)}><Pencil className="w-3.5 h-3.5" /></Button>
                <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => setDeleteTarget(c)}><Trash2 className="w-3.5 h-3.5" /></Button>
              </div>
            );
          }}
        />
      </CardContent></Card>

      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{editCustomer ? 'Edit Customer' : 'Add Customer'}</DialogTitle></DialogHeader>
          <div className="grid gap-3 py-2">
            <div className="grid gap-1.5">
              <Label>Name *</Label>
              <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Customer name" />
            </div>
            <div className="grid gap-1.5">
              <Label>Contact (Email or Phone)</Label>
              <Input value={form.contact} onChange={e => setForm(f => ({ ...f, contact: e.target.value }))} placeholder="email@example.com" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label>Group</Label>
                <Select value={form.group} onValueChange={v => setForm(f => ({ ...f, group: v as CustomerGroup }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{GROUPS.map(g => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="grid gap-1.5">
                <Label>Territory</Label>
                <Select value={form.territory} onValueChange={v => setForm(f => ({ ...f, territory: v as Territory }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{TERRITORIES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="button" onClick={handleSubmit}>{editCustomer ? 'Save Changes' : 'Create Customer'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog open={!!deleteTarget} title="Delete Customer"
        description={`Delete "${deleteTarget?.name}"?`}
        onConfirm={handleDelete} onCancel={() => setDeleteTarget(null)} />
    </div>
  );
}
