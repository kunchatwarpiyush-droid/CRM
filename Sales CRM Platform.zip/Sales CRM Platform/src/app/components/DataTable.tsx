import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ChevronLeft, ChevronRight, Download } from 'lucide-react';

interface Column<T> {
  key: string;
  label: string;
  render?: (row: T) => React.ReactNode;
}

interface Props<T> {
  data: T[];
  columns: Column<T>[];
  searchKeys?: (keyof T & string)[];
  pageSize?: number;
  onExport?: () => void;
  extraFilters?: React.ReactNode;
  actions?: (row: T) => React.ReactNode;
  onRowClick?: (row: T) => void;
}

export function DataTable<T extends object>({
  data, columns, searchKeys = [], pageSize = 10,
  onExport, extraFilters, actions, onRowClick
}: Props<T>) {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(0);

  const filtered = data.filter(row => {
    if (!search) return true;
    const q = search.toLowerCase();
    return searchKeys.some(k => String((row as Record<string, unknown>)[k] ?? '').toLowerCase().includes(q));
  });

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const pageData = filtered.slice(page * pageSize, (page + 1) * pageSize);

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 flex-wrap">
        {searchKeys.length > 0 && (
          <Input
            className="h-8 w-56 text-sm"
            placeholder="Search…"
            value={search}
            onChange={e => { setSearch(e.target.value); setPage(0); }}
          />
        )}
        {extraFilters}
        <div className="ml-auto flex items-center gap-2">
          {onExport && (
            <Button type="button" size="sm" variant="outline" className="h-8 gap-1.5 text-xs" onClick={onExport}>
              <Download className="w-3.5 h-3.5" /> Export CSV
            </Button>
          )}
        </div>
      </div>

      <div className="rounded-md border overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50">
            <tr>
              {columns.map(c => (
                <th key={c.key} className="text-left px-3 py-2.5 font-medium text-muted-foreground whitespace-nowrap">{c.label}</th>
              ))}
              {actions && <th className="px-3 py-2.5 text-right font-medium text-muted-foreground">Actions</th>}
            </tr>
          </thead>
          <tbody>
            {pageData.length === 0 ? (
              <tr><td colSpan={columns.length + (actions ? 1 : 0)} className="text-center py-10 text-muted-foreground">No records found.</td></tr>
            ) : pageData.map((row, i) => (
              <tr
                key={i}
                className={`border-t hover:bg-muted/30 transition-colors ${onRowClick ? 'cursor-pointer' : ''}`}
                onClick={() => onRowClick?.(row)}
              >
                {columns.map(c => (
                  <td key={c.key} className="px-3 py-2.5 whitespace-nowrap">
                    {c.render ? c.render(row) : String((row as Record<string, unknown>)[c.key] ?? '')}
                  </td>
                ))}
                {actions && (
                  <td className="px-3 py-2.5 text-right" onClick={e => e.stopPropagation()}>
                    {actions(row)}
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>{filtered.length} record{filtered.length !== 1 ? 's' : ''}</span>
        <div className="flex items-center gap-1">
          <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0" disabled={page === 0} onClick={() => setPage(p => p - 1)}>
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <span>Page {page + 1} of {totalPages}</span>
          <Button type="button" size="sm" variant="ghost" className="h-7 w-7 p-0" disabled={page >= totalPages - 1} onClick={() => setPage(p => p + 1)}>
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
