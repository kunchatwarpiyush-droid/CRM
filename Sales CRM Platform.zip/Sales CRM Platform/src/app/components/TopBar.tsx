import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Plus, LogOut, Menu, Clock } from 'lucide-react';
import { timeAgo } from '@/app/utils/format';

interface Props {
  user: { name: string; role: string };
  onLogout: () => void;
  onAddLead: () => void;
  onAddOpportunity: () => void;
  onAddCustomer: () => void;
  lastSynced: Date;
  onMenuToggle: () => void;
}

export function TopBar({ user, onLogout, onAddLead, onAddOpportunity, onAddCustomer, lastSynced, onMenuToggle }: Props) {
  const [, forceUpdate] = useState(0);
  // Update time display every minute
  useState(() => {
    const id = setInterval(() => forceUpdate(n => n + 1), 60000);
    return () => clearInterval(id);
  });

  const initials = user.name.split(' ').map(n => n[0]).join('').toUpperCase();

  return (
    <header className="h-14 border-b bg-card flex items-center gap-3 px-4 flex-shrink-0">
      <button onClick={onMenuToggle} className="md:hidden p-1 rounded hover:bg-accent">
        <Menu className="w-5 h-5" />
      </button>

      <div className="flex items-center gap-2 text-xs text-muted-foreground mr-auto">
        <Clock className="w-3.5 h-3.5" />
        <span>Last synced {timeAgo(lastSynced)}</span>
      </div>

      <div className="hidden sm:flex items-center gap-2">
        <Button size="sm" variant="outline" onClick={onAddLead} className="gap-1.5 text-xs h-8">
          <Plus className="w-3.5 h-3.5" /> Lead
        </Button>
        <Button size="sm" variant="outline" onClick={onAddOpportunity} className="gap-1.5 text-xs h-8">
          <Plus className="w-3.5 h-3.5" /> Opportunity
        </Button>
        <Button size="sm" variant="outline" onClick={onAddCustomer} className="gap-1.5 text-xs h-8">
          <Plus className="w-3.5 h-3.5" /> Customer
        </Button>
      </div>

      <div className="flex items-center gap-2 ml-2">
        <Avatar className="w-8 h-8">
          <AvatarFallback className="text-xs bg-primary text-primary-foreground">{initials}</AvatarFallback>
        </Avatar>
        <div className="hidden sm:block text-xs">
          <p className="font-medium leading-none">{user.name}</p>
          <p className="text-muted-foreground">{user.role}</p>
        </div>
        <Button variant="ghost" size="sm" onClick={onLogout} className="p-1.5 h-8 w-8">
          <LogOut className="w-4 h-4" />
        </Button>
      </div>
    </header>
  );
}
