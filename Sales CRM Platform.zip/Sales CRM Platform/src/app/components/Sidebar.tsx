import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard, Users, TrendingUp, UserCheck, Kanban,
  Calendar, MessageSquare, Megaphone, BarChart3, Settings, Building2
} from 'lucide-react';

interface Props { role: 'Admin' | 'Salesperson'; onClose?: () => void; }

const NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/leads', label: 'Leads', icon: Users },
  { to: '/opportunities', label: 'Opportunities', icon: TrendingUp },
  { to: '/customers', label: 'Customers', icon: UserCheck },
  { to: '/pipeline', label: 'Pipeline', icon: Kanban },
  { to: '/appointments', label: 'Appointments', icon: Calendar },
  { to: '/communications', label: 'Communications', icon: MessageSquare },
  { to: '/campaigns', label: 'Campaigns', icon: Megaphone },
  { to: '/reports', label: 'Reports', icon: BarChart3 },
];

export function Sidebar({ role, onClose }: Props) {
  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
      isActive ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-accent hover:text-foreground'
    }`;

  return (
    <aside className="w-60 bg-card border-r flex flex-col h-full">
      <div className="flex items-center gap-2 px-4 py-5 border-b">
        <Building2 className="w-6 h-6 text-primary" />
        <span className="font-bold text-lg">SalesCRM</span>
      </div>
      <nav className="flex-1 overflow-y-auto p-3 space-y-1">
        {NAV.map(({ to, label, icon: Icon }) => (
          <NavLink key={to} to={to} end={to === '/'} className={linkClass} onClick={onClose}>
            <Icon className="w-4 h-4 flex-shrink-0" />
            {label}
          </NavLink>
        ))}
        {role === 'Admin' && (
          <NavLink to="/master" className={linkClass} onClick={onClose}>
            <Settings className="w-4 h-4 flex-shrink-0" />
            Master Data
          </NavLink>
        )}
      </nav>
      <div className="p-3 border-t text-xs text-muted-foreground text-center">
        v1.0.0 · SalesCRM
      </div>
    </aside>
  );
}
