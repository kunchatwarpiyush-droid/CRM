import { Badge } from '@/components/ui/badge';
import { LeadStatus } from '@/app/data/mockData';

const MAP: Record<string, string> = {
  New: 'bg-blue-100 text-blue-800 border-blue-200',
  Contacted: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  Qualified: 'bg-green-100 text-green-800 border-green-200',
  Proposal: 'bg-purple-100 text-purple-800 border-purple-200',
  Negotiation: 'bg-orange-100 text-orange-800 border-orange-200',
  Won: 'bg-emerald-100 text-emerald-800 border-emerald-200',
  Lost: 'bg-red-100 text-red-800 border-red-200',
  Call: 'bg-cyan-100 text-cyan-800 border-cyan-200',
  Email: 'bg-indigo-100 text-indigo-800 border-indigo-200',
  'Follow-up': 'bg-pink-100 text-pink-800 border-pink-200',
};

export function StatusBadge({ status }: { status: string }) {
  const cls = MAP[status] ?? 'bg-gray-100 text-gray-800 border-gray-200';
  return (
    <Badge variant="outline" className={`text-xs font-medium ${cls}`}>
      {status}
    </Badge>
  );
}
