import { action } from '@uibakery/data';

// POST – delete a row by rowId
// params.url   = Apps Script Web App URL
// params.sheet = sheet tab name
// params.rowId = unique row ID stored in the 'id' column
function gsDelete() {
  return action('gsDelete', 'HTTP', {
    datasourceName: 'httpApi',
    options: {
      method: 'POST',
      url: '{{params.url}}',
      headers: { 'Content-Type': 'text/plain' },
      bodyType: 'raw',
      body: `{{JSON.stringify({ action: 'delete', sheet: params.sheet, rowId: params.rowId })}}`,
    },
  });
}

export default gsDelete;
