import { action } from '@uibakery/data';

// POST – update an existing row identified by rowId
// params.url   = Apps Script Web App URL
// params.sheet = sheet tab name
// params.rowId = unique row ID stored in the 'id' column
// params.data  = partial object with updated values
function gsUpdate() {
  return action('gsUpdate', 'HTTP', {
    datasourceName: 'httpApi',
    options: {
      method: 'POST',
      url: '{{params.url}}',
      headers: { 'Content-Type': 'text/plain' },
      bodyType: 'raw',
      body: `{{JSON.stringify({ action: 'update', sheet: params.sheet, rowId: params.rowId, data: params.data })}}`,
    },
  });
}

export default gsUpdate;
