import { action } from '@uibakery/data';

// POST – insert a new row into any sheet
// params.url   = Apps Script Web App URL
// params.sheet = sheet tab name
// params.data  = object of column values
function gsCreate() {
  return action('gsCreate', 'HTTP', {
    datasourceName: 'httpApi',
    options: {
      method: 'POST',
      url: '{{params.url}}',
      headers: { 'Content-Type': 'text/plain' },
      bodyType: 'raw',
      body: `{{JSON.stringify({ action: 'create', sheet: params.sheet, data: params.data })}}`,
    },
  });
}

export default gsCreate;
