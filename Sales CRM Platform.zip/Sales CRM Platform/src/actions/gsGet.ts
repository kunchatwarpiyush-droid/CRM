import { action } from '@uibakery/data';

// GET – fetches all rows for a given sheet name
// params.url  = Apps Script Web App URL (from sheetsConfig)
// params.sheet = sheet tab name (e.g. 'Leads')
function gsGet() {
  return action('gsGet', 'HTTP', {
    datasourceName: 'httpApi',
    options: {
      method: 'GET',
      url: '{{params.url}}',
      queryParams: {
        sheet: '{{params.sheet}}',
        action: 'get',
      },
    },
  });
}

export default gsGet;
